<a href="{{ route('paciente.edit', $paciente->id) }}" class="btn btn-warning py-1"><i class="fa-solid fa-file-pen"></i></a>
