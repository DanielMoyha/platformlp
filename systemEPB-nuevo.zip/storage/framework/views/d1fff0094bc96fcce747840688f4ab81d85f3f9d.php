

<?php $__env->startSection('titulo'); ?>
    Edición de Pasantes
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow mt-4">
    <div class="card-header text-center bg-info text-white fw-bold h4">Modificar datos del Pasante</div>
    <ol class="breadcrumb mb-0 p-2">
        <li class="breadcrumb-item active">Modificar datos del pasante</li>
    </ol>

    <form method="POST" action="<?php echo e(route('pasante.update', [$pasante->id])); ?>" class="needs-validation" novalidate autocomplete="off">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center p-3 pb-lg-3 p-lg-0">
            <div class="col-md-10">
                <div class="row mb-4">
                    <!-- NOMBRES -->
                    <div class="col-md-4">
                        <label for="name" class="col-form-label fw-bold-600 text-md-end">Nombre</label>

                        <div class="">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name" value="<?php echo e($pasante->name); ?>" required autofocus placeholder="Nombre Completo del pasante">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- TELÉFONO -->
                    <div class="col-md-3">
                        <label for="telefono" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Teléfono')); ?></label>

                        <input id="telefono" type="number" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono" value="<?php echo e($pasante->telefono); ?>" required autofocus placeholder="N° Celular del pasante">

                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- DIRECCIÓN -->
                    <div class="col-md-5">
                        <label for="direccion" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Dirección')); ?></label>

                        <textarea name="direccion" id="direccion" class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"
                            required autofocus placeholder="Escriba la dirección del pasante"><?php echo e($pasante->direccion); ?></textarea>

                        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-3">
                    <!-- UNIVERSIDAD -->
                    <div class="col-md-6">
                        <label for="universidad" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Universidad')); ?></label>

                        <input id="universidad" type="text" class="form-control <?php $__errorArgs = ['universidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="universidad" value="<?php echo e($pasante->universidad); ?>" required autofocus placeholder="Escriba la Universidad al que pertenece pasante">

                        <?php $__errorArgs = ['universidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- FECHA INICIO -->
                    <div class="col-md-3">
                        <label for="fecha_inicio" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Fecha de Inicio')); ?></label>

                        <input
                            class="form-control <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            type="date"
                            name="fecha_inicio"
                            id="fecha_inicio"
                            placeholder="Escriba la dirección por favor"
                            value="<?php echo e($pasante->fecha_inicio); ?>"
                            autofocus
                            required
                        >

                        <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- FECHA FINALL -->
                    <div class="col-md-3">
                        <label for="fecha_final" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Fecha de Culminación')); ?></label>

                        <input
                            class="form-control <?php $__errorArgs = ['fecha_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            type="date"
                            name="fecha_final"
                            id="fecha_final"
                            placeholder="Escriba la dirección por favor"
                            value="<?php echo e($pasante->fecha_final); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer d-flex align-items-center justify-content-end bg-transparent">
            <a href="<?php echo e(route('pasante')); ?>" class="btn btn-danger mx-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
            <button type="submit" class="btn btn-success fw-bold"><i class="fa-solid fa-circle-check"></i> Actualizar Pasante</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/personal/edit-pasante.blade.php ENDPATH**/ ?>