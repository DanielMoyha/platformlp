

<?php $__env->startSection('titulo'); ?>
    Inicio
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Sección Principal</li>
    </ol>

    <?php if($message = Session::get('success')): ?>
        <div class="position-fixed bottom-0 end-0 py-3 px-1" style="z-index: 11">
            <div class="toast align-items-center text-white bg-success" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3500">
                <div class="d-flex">
                    <div class="toast-body">
                        <?php echo e($message); ?>

                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Cards -->
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-secondary text-white mb-4 shadow">
                <div class="card-body d-flex justify-content-between">
                    <span class="h5 m-0">Plantel Institucional</span>
                    <span class="h4 m-0"><?php echo e($totalPlantel); ?></span>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4 shadow">
                <div class="card-body d-flex justify-content-between">
                    <span class="h5 m-0">Número de Casos</span>
                    <span class="h4 m-0"><?php echo e($pacientes->count()); ?></span>
                </div>
                
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4 shadow">
                <div class="card-body d-flex justify-content-between">
                    <span class="h5 m-0">Pac. sin asignación</span>
                    <span class="h4 m-0"><?php echo e($sin_asignar); ?></span>
                </div>
                
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4 shadow">
                <div class="card-body d-flex justify-content-between">
                    <span class="h5 m-0">Pac. Asignados</span>
                    <span class="h4 m-0"><?php echo e($asignados); ?></span>
                </div>
                
            </div>
        </div>
        <hr>
    </div>

    <!-- Gráficas -->
    <div id="chart_pacientes" class="mb-5 border rounded-3 shadow"></div>


    <!-- Datatable Casos -->
    <div class="card mb-4 shadow">
        <div class="card-header d-md-flex justify-content-between" style="background-color: #eee35c">
            <div class="my-2">
                <i class="fas fa-table me-1"></i>
                <span class="h5">Listado de Casos Registrados</span>
            </div>
            <div>
                <a href="<?php echo e(route('paciente.create')); ?>" class="btn fw-bold text-white" style="background-color: #78ca63"><i class="fa-solid fa-circle-plus"></i> Agregar Nuevo</a>
                <a href="<?php echo e(route('hijos')); ?>" class="btn fw-bold text-white mt-2 mt-md-0" style="background-color: #1dc6bc"><i class="fa-solid fa-table-list"></i> Ver Asignaciones</a>
            </div>
            
        </div>
        <div class="card-body">
            <table id="datatableCasos" class="table table-striped dt-responsive order-column rounded-3">
                <thead>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Caso</th>
                        <th>Nombres</th>
                        <th>Edad</th>
                        <th>Estado Civil</th>
                        <th>Cantidad de Hijos</th>
                        <th>Teléfono</th>
                        <th>Fecha</th>
                        
                        <th>Sexo</th>
                        <th>Ingreso Mensual</th>
                        <th>Nombre del Esposo(a)</th>
                        <th>Ocupación</th>
                        <th>Grado de Instrucción</th>
                        
                        
                        
                        
                        
                        
                        
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>Caso</th>
                        <th>Nombres</th>
                        <th>Edad</th>
                        <th>Estado Civil</th>
                        <th>Cantidad de Hijos</th>
                        <th>Teléfono</th>
                        <th>Fecha</th>
                        
                        <th>Sexo</th>
                        <th>Ingreso Mensual</th>
                        <th>Nombre del Esposo(a)</th>
                        <th>Ocupación</th>
                        <th>Grado de Instrucción</th>
                        
                        
                        
                        
                        
                        
                        
                    </tr>
                </tfoot>
                
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    //
    

    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>
    <script>
        // estas variables son creadas acá, pero después debe estar el archivo que recibe estar variables, en este caso, highcharts.js
        let year = new Date().getFullYear();
        var datas = <?php echo json_encode($datas); ?>;
        var pacientesMasculinos = <?php echo json_encode($pacientesMasculinos); ?>;
        var pacientesFemeninos = <?php echo json_encode($pacientesFemeninos); ?>;
        
    </script>
    <script src="<?php echo e(asset('js/highcharts.js')); ?>" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>

    <script>

        $(document).ready(function () {
            $(".toast").toast('show');

            $("#datatableCasos").DataTable({
                "ajax": "<?php echo e(route('data.casos')); ?>",
                "columns": [
                    {data: '', name:'', orderable: false, searchable: false},
                    {data: 'view', name:'view', orderable: false, searchable: false },
                    {data: 'edit', name:'edit', orderable: false, searchable: false },
                    {data: 'caso'},
                    {data: 'nombres'},
                    {data: 'edad'},
                    {data: 'estado_civil'},
                    {data: 'cantidad_hijos', name:'cantidad_hijos'},
                    {data: 'telefono'},
                    {data: 'fecha'},
                    {data: 'sexo', name:'sexo'},
                    {data: 'ingreso_mensual'},
                    {data: 'nombre_esposo'},
                    {data: 'ocupacion'},
                    {data: 'grado_instruccion'},
                ],
                //responsive: true,
                responsive: {
                    details: {
                        renderer: function ( api, rowIdx, columns ) {
                            var data = $.map( columns, function ( col, i ) {
                                return col.hidden ?
                                    '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
                                        '<td class="fw-bold col-8">'+col.title+':'+'</td> '+
                                        '<td>'+col.data+'</td>'+
                                    '</tr>' : '';
                            } ).join('');
         
                            return data ? $('<table/>').append( data ) : false;
                        }
                    }
                },
                /*dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'landscape',
                        pageSize: 'LEGAL',
                        title: `Lista de Casos de la gestión ${year}`,
                        exportOptions: { orthogonal: 'export' }
                    },
                    {
                        extend: 'excelHtml5',
                        title: `Lista de Casos de la gestión ${year}`,
                        exportOptions: { orthogonal: 'export' }
                    }
                ],*/
                /*'columnDefs': [ {
                    'targets': [0],//deshabilitar arrows de las columnas seleccionadas[0,1,2]
                    'orderable': false,
                 }],*/
                autoWidth: false,
                language: {
                    thousands: ",",
                    lengthMenu:
                        "Mostrar " +
                        `<select class="custom-select custom-select-sm form-control form-control-sm" >
                            <option value='5'>5</option>
                            <option value='10'>10</option>
                            <option value='25'>25</option>
                            <option value='50'>50</option>
                            <option value='100'>100</option>
                            <option value='-1'>Todos</option>
                        </select>` +
                        " Registros por página",
                    zeroRecords: "Registros no encontrados",
                    // info: "Mostrando la página _PAGE_ de _PAGES_",
                    info: "Mostrando registros del _START_ al _END_ de _TOTAL_ registros",
                    // emptyTable: "No hay registros disponibles",
                    infoEmpty: "No hay registros disponibles",
                    infoFiltered: `</br>` + "(Búsqueda filtrada de _MAX_ registros totales)",
                    search: "Buscar",
                    //loadingRecords: "Cargando Información...",
                    loadingRecords: `<i class="fa fa-spinner fa-spin px-2"></i> <span class="text-muted h5">Cargando datos...</span>`,
                    paginate: {
                        next: "Siguiente",
                        previous: "Anterior",
                    },
                },
            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>