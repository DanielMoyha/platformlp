

<?php $__env->startSection('titulo'); ?>
    Designar Encargada a los Hijos
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Crear Hijos</li>
    </ol>

    <div class="row" onload="RenderInputs()">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombres:</strong>
                <?php echo e($hijo->paciente->nombres); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Hijos:</strong>
                <?php echo e($hijo->paciente->cantidad_hijos); ?>

            </div>
        </div>

        <!--Cantidad de Hijos-->
        <div class="col-md-3 mb-2">
            <label for="cantidad_hijos" class="form-label">Cantidad de Hijos</label>
            <input type="number" class="form-control" id="cantidad_hijos" name="cantidad_hijos" min="0"
                placeholder="Introduzca la cantidad de Hijos que tiene" value="<?php echo e($hijo->paciente->cantidad_hijos); ?>">
            <div class="invalid-feedback">
                Introduzca la cantidad de Hijos
            </div>
        </div>

        <!--START Car Group 2 - Hijos -->

        <form action="<?php echo e(route('paciente.hijos.update', $hijo->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="row d-flex justify-content-start mb-3" id="content-hijos"></div>

            <button type="submit" class="btn btn-success">Actualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            
            
            /** Generar campos por la cantidad de hijos */
            $(function () {
                $("#cantidad_hijos").keyup(function () {
                    let cantidad = $("#cantidad_hijos").val();
                    RenderInputs(cantidad);
                });
            });
        
            function RenderInputs(cantidad) {
                $("#content-hijos").html("");
        
                for (let i = 0; i < cantidad; i++) {
                    // $("#content-hijos").append('<form class="form">');
                    $("#content-hijos").append(`
                        <div class="card-group mb-3">
                            <div class="card">
                                <div class="card-body d-flex justify-content-start">
                                    <input name="paciente_id[]" type="text" value="<?php echo e($hijo->paciente->id); ?>" hidden>
                                    <div class="col-md-5 mb-2 mx-2">
                                        <label
                                            for="nombre_hijo` + (i + 1) +`"
                                            class="form-label fw-bold">
                                                Nombre del Hijo(a)
                                        </label>
                                        <input
                                            type="text"
                                            class="form-control"
                                            id="nombre_hijo` + (i + 1) +`"
                                            name="nombre[]
                                            placeholder="Nombre Completo de su hijo(a)"
                                            value="<?php echo e($hijo->nombre); ?>"
                                            required
                                        />
                                    </div>
        
                                    <div class="col-md-2 mb-2 mx-2">
                                        <label
                                            for="edad_hijo` + (i + 1) +`"
                                            class="form-label fw-bold">
                                                Edad
                                        </label>
                                        <input
                                            type="number"
                                            class="form-control"
                                            id="edad_hijo` + (i + 1) +`"
                                            name="edad[]"
                                            min="0"
                                            placeholder="Edad del hijo(a)"
                                            value="<?php echo e($hijo->edad); ?>"
                                            required
                                        />
                                    </div>
        
                                    <div class="col-md-2 mb-2 mx-2">
                                        <label for="sexo-hijo` +
                                        (i + 1) +
                                        `" class="form-label fw-bold">Sexo</label>
                                        <select class="form-select" id="sexo-hijo` +
                                        (i + 1) +
                                        `" name="sexo[]" required>
                                            <option selected disabled>-- Seleccione --</option>
                                            <option value="Masculino" <?php echo e($hijo->sexo == 'Masculino' ? 'selected' : ''); ?>>Masculino</option>
                                            <option value="Femenino" <?php echo e($hijo->sexo == 'Femenino' ? 'selected' : ''); ?>>Femenino</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Elija el sexo del hijo(a), por favor.
                                        </div>
                                    </div>

                                    <div class="col-md-2 mb-2 mx-2">
                                        <label for="asignar" class="col-form-label fw-bold">Encargada:</label>
                                        <select name="user_id[]" class="form-control">
                                            <option value=""> -- Seleccione --</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php echo e($hijo->user_id == $user->id ? 'selected' : ''); ?>>
                                                    <?php echo e($user->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `);
                }
            }
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pacientes/edit-hijos.blade.php ENDPATH**/ ?>