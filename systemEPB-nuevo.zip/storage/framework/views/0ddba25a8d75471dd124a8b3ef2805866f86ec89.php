

<?php $__env->startSection('titulo'); ?>
    Registrar Nuevo Voluntario
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="d-flex justify-content-end">
        <a href="<?php echo e(route('personal.create')); ?>" class="btn btn-success mx-1 mb-2"><i class="fa-solid fa-user-tie mx-1"></i> Nuevo Administrativo</a>
        <a href="<?php echo e(route('pasante.create')); ?>" class="btn btn-success mx-1 mb-2"><i class="fa-solid fa-user-clock mx-1"></i> Nuevo Pasante</a>
    </div>
</div>
<div class="card border-info mb-5 shadow">
    <div class="card-header text-center bg-info text-white fw-bold h4">Formulario para un Nuevo Voluntario</div>
    <ol class="breadcrumb mb-0 p-2">
        <li class="breadcrumb-item active">Nuevo Voluntario que pasará a formar parte de la institución</li>
    </ol>
    <form method="POST" action="<?php echo e(route('voluntario.store')); ?>" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center p-3 pb-lg-3 p-lg-0">
            <div class="col-md-10">
                    <div class="row mb-4">
                        <!-- NOMBRES -->
                        <div class="col-md-4">
                            <label for="name" class="col-form-label text-md-end">Nombre</label>

                            <div class="">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Nombre Completo del voluntario">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- TELÉFONO -->
                        <div class="col-md-3">
                            <label for="telefono" class="col-form-label text-md-end"><?php echo e(__('Teléfono')); ?></label>

                            <input id="telefono" type="number" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus placeholder="N° Celular del voluntario">

                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- DIRECCIÓN -->
                        <div class="col-md-5">
                            <label for="direccion" class="col-form-label text-md-end"><?php echo e(__('Dirección')); ?></label>

                            <textarea name="direccion" id="direccion" class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"
                                required autofocus placeholder="Escriba la dirección del voluntario"><?php echo e(old('direccion')); ?></textarea>

                            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <!-- PROFESIÓN -->
                        <div class="col-md-6">
                            <label for="profesion" class="col-form-label text-md-end"><?php echo e(__('Profesión')); ?></label>

                            <input id="profesion" type="text" class="form-control <?php $__errorArgs = ['profesion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="profesion" value="<?php echo e(old('profesion')); ?>" required autofocus placeholder="Escriba la profesión del Voluntario">

                            <?php $__errorArgs = ['profesion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
            </div>
        </div>
        <div class="card-footer d-flex align-items-center justify-content-end">
            <a href="<?php echo e(route('voluntario')); ?>" class="btn btn-danger fw-bold mx-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
            <button type="submit" class="btn btn-primary fw-bold"><i class="fa-solid fa-circle-check"></i> Registrar Voluntario</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/personal/create-voluntario.blade.php ENDPATH**/ ?>