

<?php $__env->startSection('titulo'); ?>
    Ver Caso
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Mostrar Caso</li>
        </ol>
    </div>

    <div class="card border-0 shadow">
        <div class="card-header text-center bg-info text-white h5 fw-bold"><i class="fa-solid fa-box-archive"></i> ATENCIÓN DE CASO - TRABAJO SOCIAL</div>
        <div class="card-body">
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600">N° de Caso: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->caso); ?></span>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-calendar-day"></i> Fecha: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->fecha); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-clock"></i> Hora: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->hora); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-address-card"></i> Nombre y Apellido: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->nombres); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600">Edad: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->edad); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-mars-and-venus"></i> Sexo: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->sexo); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-5">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-location-dot"></i> Dirección: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->direccion); ?></span>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-phone"></i> Teléfono: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->telefono); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-phone"></i> Num. Referencia: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->telefono_referencia); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-person-circle-question"></i> Estado Civil: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->estado_civil); ?></span>
                    </div>
                    <div class="col-md-7">
                        <label class="form-label fw-bold-600">Años: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->anios); ?></span>
                    </div>
                    
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-address-card"></i> Nombre del esposo(a): </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->nombre_esposo); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600">Edad: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->edad_esposo); ?></span>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-user-graduate"></i> Grado de Instrucción: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->grado_instruccion); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-12">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-children"></i> Cuántos Hijos tiene: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->cantidad_hijos); ?></span>
                    </div>
                </div>
            </div>

            <!--HIJOS-->
            <div class="row p-2">
                <?php $__currentLoopData = $paciente->hijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-md-flex justify-content-between shadow-sm rounded-3 mt-2 mt-md-1">
                        <div class="col-md-4">
                            <label class="form-label fw-bold-600">Nombre: </label>
                            <span class="fst-italic text-muted"><?php echo e($hijo->nombre); ?></span>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold-600"><i class="fa-solid fa-mars-and-venus"></i> Sexo: </label>
                            <span class="fst-italic text-muted"><?php echo e($hijo->sexo); ?></span>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-bold-600">Edad: </label>
                            <span class="fst-italic text-muted"><?php echo e($hijo->edad); ?></span>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold-600">Encargada: </label>
                            <?php if($hijo->user_id === null || empty($hijo->user_id)): ?>
                                <span class="fst-italic text-muted">Sin Encargada</span>
                            <?php else: ?>
                                <span class="fst-italic text-muted"><?php echo e($hijo->user->name); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--END HIJOS-->

            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-user-tie"></i> Ocupación: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->ocupacion); ?></span>
                    </div>
                    <div class="col-md-7">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-sack-dollar"></i> Ingreso Mensual: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->ingreso_mensual); ?></span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-12">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-file-lines"></i> Motivo de Consulta: </label>
                        <div class="fst-italic text-muted"><?php echo e($paciente->motivo_consulta); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow my-4">
        <div class="card-header text-center bg-info text-white h5 fw-bold"><i class="fa-solid fa-clipboard-question"></i> ENTREVISTA INICIAL</div>
        <div class="card-body">
            <div class="row">
                <div class="d-md-flex justify-content-between">
                    <div class="col-md-12">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-timeline"></i> Historia Familiar: </label>
                        <div class="fst-italic text-muted"><?php echo e($paciente->historia_familiar); ?></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between text-center">
                    <div class="col-md-12 mt-3">
                        <label class="form-label text-uppercase fw-bold text-muted fst-italic">
                            <u>Estructura y Dinámica Familiar.</u>
                        </label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between border-bottom">
                    <div class="col-md-4">
                        <label class="form-label fw-bold-600">Tipo de Familia: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->tipo_familia); ?></span>
                    </div>
                    <div class="col-md-7">
                        <label class="form-label fw-bold-600">Tipo: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->tipo); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between text-center">
                    <div class="col-md-12 mt-3">
                        <label class="form-label text-uppercase fw-bold text-muted fst-italic">
                            <u>Las Relaciones Familiares.</u>
                        </label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-evenly">
                    <div class="col-md-6">
                        <label class="form-label fw-bold-600">Relación Conyugal: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->conyugal); ?></span>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold-600">Relación Materno-Filial: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->materno); ?></span>
                    </div>
                </div>
                <div class="d-md-flex justify-content-evenly border-bottom">
                    <div class="col-md-6">
                        <label class="form-label fw-bold-600">Relación Paterno-Filial: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->paterno); ?></span>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold-600">Relación Fraterno-Filial: </label>
                        <span class="fst-italic text-muted"><?php echo e($paciente->fraterno); ?></span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between mt-3">
                    <div class="col-md-12">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-person-circle-exclamation"></i> Diagnóstico Social: </label>
                        <div class="fst-italic text-muted"><?php echo e($paciente->diagnostico_social); ?></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-md-flex justify-content-between my-3">
                    <div class="col-md-12">
                        <label class="form-label fw-bold-600"><i class="fa-solid fa-clipboard-list"></i> Acciones a Seguir: </label>
                        <div class="fst-italic text-muted"><?php echo e($paciente->acciones); ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-end bg-transparent">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-danger fw-bold"><i class="fa-solid fa-arrow-left"></i> Regresar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pacientes/show-caso.blade.php ENDPATH**/ ?>