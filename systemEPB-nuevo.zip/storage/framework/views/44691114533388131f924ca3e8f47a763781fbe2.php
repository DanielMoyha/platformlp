

<?php $__env->startSection('titulo'); ?>
    Sesiones
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Sesiones realizadas por pacientes</li>
    </ol>
    <div class="row mb-3">
        <div class="col-md-6">
            
        </div>
    </div>

    <!-- Datatable - Pasantes -->
    
    <table id="datatableSesiones" class="table table-striped dt-responsive shadow rounded-3">
        <thead class="text-center" style="background-color: #f9f9f9">
            <tr>
                <th class="text-center">Caso</th>
                <th class="text-center">Nombre del Paciente</th>
                <th class="text-center">Sesiones Realizadas</th>
                <th class="text-center">Última Sesión</th>
                <th class="text-center">Encargada</th>
            </tr>
        </thead>
        <tfoot class="text-center" style="background-color: #f9f9f9">
            <tr>
                <th class="text-center">Caso</th>
                <th class="text-center">Nombre del Paciente</th>
                <th class="text-center">Sesiones Realizadas</th>
                <th class="text-center">Última Sesión</th>
                <th class="text-center">Encargada</th>
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center">
                        <?php if(empty($paciente->num_caso) || $paciente->num_caso == null): ?>
                            <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                Sin caso
                            </small>
                        <?php else: ?>
                            <span class="fw-bold fst-italic text-muted"><?php echo e($paciente->num_caso); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="">
                        <?php if(empty($paciente->nombre) || $paciente->nombre == null): ?>
                            <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                Sin nombre
                            </small>
                        <?php else: ?>
                            <span><?php echo e($paciente->nombre); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if(empty($paciente->num_sesion) || $paciente->num_sesion == null): ?>
                            <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                Sin Sesiones
                            </small>
                        <?php else: ?>
                            <span class="fw-bold">
                                <?php echo e($paciente->num_sesion); ?>

                            </span>
                            <span class="badge bg-success fst-italic">
                                <?php echo app('translator')->choice('Completada|Completadas', $paciente->num_sesion); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if(empty($paciente->ultima_fecha) || $paciente->ultima_fecha == null): ?>
                            <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                Sin Fecha
                            </small>
                        <?php else: ?>
                            <span class="bg-warning small fst-italic text-white rounded-pill px-2 py-1 fw-bold">
                                <i class="fa-solid fa-calendar-check mx-1"></i><?php echo e(Carbon\Carbon::parse($paciente->ultima_fecha)->format('d-m-Y')); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if(empty($paciente->encargada) || $paciente->encargada == null): ?>
                            <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                Sin Encargada
                            </small>
                        <?php else: ?>
                        <span class="bg-info p-1 rounded-2 small text-white fw-bold fst-italic"><?php echo e($paciente->encargada); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/sessions/index.blade.php ENDPATH**/ ?>