

<?php $__env->startSection('titulo'); ?>
    Registrar Nuevo Personal Administrativo
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        #togglePassword{
            cursor: pointer;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="d-flex justify-content-end">
        <a href="<?php echo e(route('pasante.create')); ?>" class="btn btn-success mx-1 mb-2"><i class="fa-solid fa-user-clock mx-1"></i> Nuevo Pasante</a>
        <a href="<?php echo e(route('personal.create')); ?>" class="btn btn-success mx-1 mb-2"><i class="fa-solid fa-user-gear mx-1"></i> Nuevo Voluntario</a>
    </div>
</div>
<div class="card mt-2 my-5 shadow border-0">
    <div class="card-header text-center bg-info text-white fw-bold h4">Fomulario para Nuevo Personal</div>
    <ol class="breadcrumb mb-4 p-2">
        <li class="breadcrumb-item active">Nuevo Integrante para formar parte del plantel administrativo</li>
    </ol>

    <div class="row justify-content-center px-3 px-md-0">
        <div class="col-md-10">
            <form action="<?php echo e(route('personal.store')); ?>" method="POST" class="needs-validation" autocomplete="off" novalidate>
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <!-- NOMBRES -->
                    <div class="col-md-4">
                        <label for="name" class="col-form-label fw-bold-600 text-md-end">Nombre</label>

                        <div class="">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Nombre Completo">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- CARGO - ROL -->
                    <div class="col-md-3">
                        <label for="role_id" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Cargo')); ?></label>

                        <select name="role_id" id="role_id" class="form-control <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option selected disabled>--Seleccione un Cargo--</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- USERNAME -->
                    <div class="col-md-2">
                        <label for="username" class=" col-form-label fw-bold-600 text-md-end"><?php echo e(__('Usuario')); ?></label>

                            <input id="username" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Nombre de Usuario" autofocus required>

                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- CARNÉT DE IDENTIDAD -->
                    <div class="col-md-3">
                        <label for="ci" class="col-form-label fw-bold-600"><?php echo e(__('Carnét de Identidad')); ?></label>

                        <input id="ci" type="number" class="form-control <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ci" value="<?php echo e(old('ci')); ?>" placeholder="12345678" required autofocus>

                        <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-2">
                    <!-- CORREO ELECTRÓNICO -->
                    <div class="col-md-4">
                        <label for="email" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Correo Electrónico')); ?></label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="email" value="<?php echo e(old('email')); ?>" required placeholder="ejemplo@gmail.com">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- TELÉFONO -->
                    <div class="col-md-2">
                        <label for="telefono" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Teléfono')); ?></label>

                        <input id="telefono" type="number" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus placeholder="7777777">

                        <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- DIRECCIÓN -->
                    <div class="col-md-6">
                        <label for="direccion" class="col-form-label fw-bold-600 text-md-end"><?php echo e(__('Dirección')); ?></label>

                        <textarea name="direccion" id="direccion" class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"
                            required autofocus placeholder="Escriba la dirección por favor"><?php echo e(old('direccion')); ?></textarea>

                        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>


                <div class="row mb-4">
                    <!-- CONTRASEÑA -->
                    <div class="col-md-4">
                        <label for="password" class="col-form-label fw-bold-600 text-md-end">Contraseña</label>

                        <div class="input-group">
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                            <span class="input-group-text" onclick="password_show_hide();" role="button">
                                <i class="fas fa-eye" id="show_eye"></i>
                                <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                            </span>
                        </div>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="text-end">
                        <a href="<?php echo e(route('personal')); ?>" class="btn btn-danger fw-bold mx-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
                        <button type="submit" class="btn btn-success fw-bold"><i class="fa-solid fa-circle-check"></i> Registrar Administrativo</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

        <script>
            function password_show_hide() {
                let x = document.getElementById("password");
                let show_eye = document.getElementById("show_eye");
                let hide_eye = document.getElementById("hide_eye");
                hide_eye.classList.remove("d-none");
                if (x.type === "password") {
                  x.type = "text";
                  show_eye.style.display = "none";
                  hide_eye.style.display = "block";
                } else {
                  x.type = "password";
                  show_eye.style.display = "block";
                  hide_eye.style.display = "none";
                }
            }

            function password_confirm_show_hide() {
                let x = document.getElementById("password-confirm");
                let show_eye = document.getElementById("show_eye_c");
                let hide_eye = document.getElementById("hide_eye_c");
                hide_eye.classList.remove("d-none");
                if (x.type === "password") {
                  x.type = "text";
                  show_eye.style.display = "none";
                  hide_eye.style.display = "block";
                } else {
                  x.type = "password";
                  show_eye.style.display = "block";
                  hide_eye.style.display = "none";
                }
            }

            //let usernameInput = document.getElementsByName("username")[0];
            let ciInput = document.getElementsByName("ci")[0];
            let passwordInput = document.getElementsByName("password")[0];

            function process(e) {
                passwordInput.value = e.target.value.replace(/\s/g, '-');
            }
            ciInput.addEventListener("input", process);
        </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/personal/create.blade.php ENDPATH**/ ?>