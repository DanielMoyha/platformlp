

<?php $__env->startSection('titulo'); ?>
    Voluntarios
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable.css')); ?>">
    <style>
        .error {
          color: #ca0505;
        }

        
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Usuarios</li>
    </ol>
    <?php if($message = Session::get('success')): ?>
        <div class="position-fixed mt-5 top-0 end-0 py-3 px-1" style="z-index: 11">
            <div class="toast align-items-center text-white bg-success" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3500">
                <div class="d-flex">
                    <div class="toast-body">
                        <?php echo e($message); ?>

                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"
                    aria-label="Close"></button>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row mb-3">
        <div class="col-md-8">
            <a href="<?php echo e(route('personal')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-tie mx-1"></i> Ver Administrativos</a>
            <a href="<?php echo e(route('pasante')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-clock mx-1"></i> Ver Pasantes</a>
            <a href="<?php echo e(route('voluntario')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-gear mx-1"></i> Ver Voluntarios</a>
        </div>
    </div>

    <!-- Datatable - Voluntarios -->
    <div class="card mb-5 shadow table-voluntarios">
        <div class="card-header d-md-flex justify-content-between bg-info">
            <div class="my-2">
                <i class="fas fa-table me-1"></i>
                <span class="h5 text-dark">Listado de los Voluntarios de la Institución</span>
            </div>
            <div class="">
                <a href="<?php echo e(route('voluntario.create')); ?>" class="btn btn-success fw-bold"><i class="fa-solid fa-circle-plus"></i> Registrar Nuevo</a>
            </div>
        </div>
        <div class="card-body">
            <table id="datatableVoluntarios" class="table table-striped dt-responsive order-column">
                <thead>
                    <tr>
                        
                        <th></th>
                        <th>Estado</th>
                        <th>Nombre Completo</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Profesión</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tfoot>
                    
                    <tr>
                        <th></th>
                        <th>Estado</th>
                        <th>Nombre Completo</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Profesión</th>
                        <th>Acciones</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $voluntarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voluntario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="form-check form-switch">
                                    <input data-id="<?php echo e($voluntario->id); ?>" class="form-check-input mi_checkbox"
                                    type="checkbox" data-onstyle="success" data-offstyle="danger"
                                    data-toggle="toggle" data-on="Active" data-off="InActive"
                                    <?php echo e($voluntario->estado ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                                </div>
                            </td>
                            <td id="resp<?php echo e($voluntario->id); ?>">
                                <?php if($voluntario->estado == 0 || empty($voluntario->estado) || $voluntario->estado == null): ?>
                                    <span class="badge bg-danger">Inactivo</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Activo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($voluntario->name) || $voluntario->name == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Nombre
                                    </small>
                                <?php else: ?>
                                    <?php echo e($voluntario->name); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($voluntario->telefono) || $voluntario->telefono == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($voluntario->telefono); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($voluntario->direccion) || $voluntario->direccion == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Dirección
                                    </small>
                                <?php else: ?>
                                    <?php echo e($voluntario->direccion); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($voluntario->profesion) || $voluntario->profesion == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Profesión
                                    </small>
                                <?php else: ?>
                                    <?php echo e($voluntario->profesion); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex justify-between">
                                    <a href="<?php echo e(route('voluntario.edit', [$voluntario->id])); ?>" class="bg-warning text-white mx-2 py-1 px-2 rounded-pill">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <button type="button" class="btn btn-danger text-white mx-2 py-1 px-2 rounded-pill deleteRecord" data-bs-toggle="modal" data-bs-target="#modalDeleteConfirm" value="<?php echo e($voluntario->id); ?>"><i class="fa-solid fa-trash-can"></i></button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="modalDeleteConfirm" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteConfirmLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('voluntario.destroy', $voluntario->id)); ?>" method="POST">
                                                
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteConfirmLabel">Eliminar Registro</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="id" id="id">
                                                        <h5>¿Está seguro de eliminar este registro?</h5>
                                                        <h6>No podrá recuperar el registro más adelante</h6>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                                                        <button type="submit" class="btn btn-danger">Sí, Eliminar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>
    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $(".toast").toast('show');
            $(document).on('click', '.deleteRecord', function(e) {
                e.preventDefault();

                var record_id = $(this).val();
                $('#id').val(record_id);
                $('#modalDeleteConfirm').modal('show');
            });

            $('.mi_checkbox').change(function() {
                //Verifica el estado del checkbox, select = 1, sino select = 0
                var estado = $(this).prop('checked') == true ? 1 : 0;
                var id = $(this).data('id');
                //console.log(estado);
                $.ajax({
                    type: "GET",
                    dataType: "json",
                    url: '<?php echo e(route('voluntario.estado')); ?>',
                    data: {
                        'estado': estado,
                        'id': id
                    },
                    success: function(data) {
                        $('#resp' + id).html(data.var);
                    }
                });
            });

        });

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/personal/voluntarios.blade.php ENDPATH**/ ?>