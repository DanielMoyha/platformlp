

<?php $__env->startSection('titulo'); ?>
    Registrar Nuevo Caso
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />

    <style>
        .error {
            color: #FF0000;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Formulario para registrar un Nuevo Caso</li>
    </ol>

    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong><i class="fa-solid fa-triangle-exclamation"></i> Tomar en cuenta!</strong>
        <span>Asegurese de introducir la cantidad exacta de hijos que tiene el paciente, por favor.</span>
        <small class="fst-italic">(Para evitar errores a futuro)</small>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <div class="card border-0 mb-5 shadow-sm">
        <div class="card-header text-center bg-info text-white fw-bold h4">
            <i class="fa-solid fa-folder-open"></i> Atención de Caso - Trabajo Social
        </div>

        
        <form action="<?php echo e(route('paciente.store')); ?>" method="POST" class="" id="formPacientes" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="p-1">
                
                <!--START Card group 1-->
                <div class="card-group mb-3">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="row d-flex justify-content-between mb-3 mt-1">
                                <!--N° Caso-->
                                <div class="col-md-12 mb-2">
                                    <label class="visually-hidden" for="caso">Caso</label>
                                    <div class="input-group">
                                        <div class="input-group-text">N° Caso</div>
                                        <input type="number" class="form-control <?php $__errorArgs = ['caso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="caso" placeholder="Número de caso" name="caso"
                                            value="<?php echo e(old('caso')); ?>" min="0" required>
                                        <?php $__errorArgs = ['caso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                

                                <!--Fecha-->
                                <div class="col-md-7 mb-2">
                                    <label class="form-label fw-bold" for="fecha">Fecha</label>
                                    <div class="input-group">
                                        
                                        <input type="date" class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="fecha" name="fecha" value="<?php echo e(old('fecha')); ?>" required>
                                        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!--Hora-->
                                <div class="col-md-5 mb-2">
                                    <label class="form-label fw-bold" for="hora">Hora</label>
                                    <div class="input-group">
                                        
                                        <input type="time" class="form-control <?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="hora" name="hora" value="<?php echo e(old('hora')); ?>" required>
                                        <?php $__errorArgs = ['hora'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row d-flex justify-content-between mb-2">
                                <!--Nombre Completo-->
                                <div class="col-md-12 mb-2">
                                    <label for="nombres"
                                        class="form-label <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Nombres Completo
                                        <span class="text-muted fst-italic small">(Madre o Padre o Tutor)</span></label>
                                    <input type="text" class="form-control" id="nombres" name="nombres"
                                        placeholder="Nombre Completo" value="<?php echo e(old('nombres')); ?>" required>
                                    <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Edad-->
                                <div class="col-md-4 mb-2">
                                    <label for="edad"
                                        class="form-label <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Edad</label>
                                    <input type="number" class="form-control" id="edad" name="edad"
                                        value="<?php echo e(old('edad')); ?>" min="0" placeholder="Edad" required>
                                    <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Sexo-->
                                <div class="col-md-8 mb-2 p-md-0">
                                    <label for="sexo"
                                        class="form-label <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Sexo</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input sexo" type="radio" name="sexo" id="masculino"
                                            value="0" <?php echo e(old('sexo') == '0' ? 'checked' : ''); ?> required>
                                        <label class="form-check-label" for="masculino">Masculino</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input sexo" type="radio" name="sexo" id="femenino"
                                            value="1" <?php echo e(old('sexo') == '1' ? 'checked' : ''); ?> required>
                                        <label class="form-check-label" for="femenino">Femenino</label>
                                    </div>
                                    <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Dirección-->
                                <div class="col-md-12">
                                    <label for="direccion"
                                        class="form-label <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Dirección</label>
                                    <textarea class="form-control" id="direccion" name="direccion" placeholder="Escriba la dirección" required><?php echo e(old('direccion')); ?></textarea>
                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="row d-flex justify-content-between mb-3 mt-1">
                                <!--Teléfono-->
                                <div class="col-md-6 mb-2">
                                    <label for="telefono"
                                        class="form-label <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Teléfono</label>
                                    <input type="number" class="form-control" id="telefono" name="telefono"
                                        placeholder="00000000" value="<?php echo e(old('telefono')); ?>" required>
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Número de Referencia-->
                                <div class="col-md-6 mb-2">
                                    <label for="telefono_referencia"
                                        class="form-label <?php $__errorArgs = ['telefono_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Num.
                                        Referencia</label>
                                    <input type="number" class="form-control" id="telefono_referencia"
                                        name="telefono_referencia" value="<?php echo e(old('telefono_referencia')); ?>"
                                        placeholder="00000000" required>
                                    <?php $__errorArgs = ['telefono_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Estado Civil-->
                                <div class="col-md-6 mb-2">
                                    <label for="estado_civil"
                                        class="form-label fw-bold">Estado
                                        Civil</label>
                                    <select class="form-select <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="estado_civil" name="estado_civil" required>
                                        <option selected disabled value="">-- Seleccione --</option>
                                        <option value="casado" <?php echo e(old('estado_civil') == 'casado' ? 'selected' : ''); ?>>
                                            Casado</option>
                                        <option value="Viudo" <?php echo e(old('estado_civil') == 'Viudo' ? 'selected' : ''); ?>>
                                            Viudo</option>
                                        <option value="Divorciado"
                                            <?php echo e(old('estado_civil') == 'Divorciado' ? 'selected' : ''); ?>>Divorciado</option>
                                        <option value="Separado"
                                            <?php echo e(old('estado_civil') == 'Separado' ? 'selected' : ''); ?>>Separado</option>
                                        <option value="Soltero" <?php echo e(old('estado_civil') == 'Soltero' ? 'selected' : ''); ?>>
                                            Soltero</option>
                                        <option value="Union Libre"
                                            <?php echo e(old('estado_civil') == 'Union Libre' ? 'selected' : ''); ?>>Union Libre
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Años-->
                                <div class="col-md-6 mb-2">
                                    <label for="anios"
                                        class="form-label <?php $__errorArgs = ['anios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Años</label>
                                    <input type="number" class="form-control" id="anios" name="anios"
                                        value="<?php echo e(old('anios')); ?>" min="0" placeholder="Años del estado civil"
                                        required>
                                    <?php $__errorArgs = ['anios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Nombres completo del Esposo-->
                                <div class="col-md-12 mb-2">
                                    <label for="nombre_esposo"
                                        class="form-label <?php $__errorArgs = ['nombre_esposo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Nombres
                                        completo del Esposo(a)</label>
                                    <input type="text" class="form-control" id="nombre_esposo" name="nombre_esposo"
                                        value="<?php echo e(old('nombre_esposo')); ?>" placeholder="Nombre Completo" required>
                                    <?php $__errorArgs = ['nombre_esposo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Edad del Esposo-->
                                <div class="col-md-5 mb-2">
                                    <label for="edad_esposo"
                                        class="form-label <?php $__errorArgs = ['edad_esposo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Edad
                                        Esposo(a)</label>
                                    <input type="number" class="form-control" id="edad_esposo" name="edad_esposo"
                                        min="0" value="<?php echo e(old('edad_esposo')); ?>" placeholder="Edad esposo"
                                        required>
                                    <?php $__errorArgs = ['edad_esposo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Grado de Instrucción-->
                                <div class="col-md-7 mb-2">
                                    <label for="grado_instruccion"
                                        class="form-label <?php $__errorArgs = ['grado_instruccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Grado
                                        de Instrucción</label>
                                    <select class="form-select" id="grado_instruccion" name="grado_instruccion" required>
                                        <option selected disabled value="">-- Seleccione --</option>
                                        <option value="Primaria"
                                            <?php echo e(old('grado_instruccion') == 'Primaria' ? 'selected' : ''); ?>>Primaria
                                        </option>
                                        <option value="Secundaria"
                                            <?php echo e(old('grado_instruccion') == 'Secundaria' ? 'selected' : ''); ?>>Secundaria
                                        </option>
                                        <option value="Bachiller"
                                            <?php echo e(old('grado_instruccion') == 'Bachiller' ? 'selected' : ''); ?>>Bachiller
                                        </option>
                                        <option value="Profesional"
                                            <?php echo e(old('grado_instruccion') == 'Profesional' ? 'selected' : ''); ?>>Profesional
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['grado_instruccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Cantidad de Hijos-->
                                <div class="col-md-12 mb-2">
                                    <label for="cantidad_hijos"
                                        class="form-label <?php $__errorArgs = ['cantidad_hijos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Cantidad
                                        de Hijos</label>
                                    <input type="number" class="form-control" id="cantidad_hijos" name="cantidad_hijos"
                                        value="<?php echo e(old('cantidad_hijos')); ?>" min="0"
                                        placeholder="Introduzca la cantidad de Hijos que tiene" required>
                                    <?php $__errorArgs = ['cantidad_hijos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="row d-flex justify-content-between mb-3">
                                <!--Ocupación-->
                                <div class="col-md-12 mb-2">
                                    <label for="ocupacion"
                                        class="form-label <?php $__errorArgs = ['ocupacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Ocupación</label>
                                    <input type="text" class="form-control" id="ocupacion" name="ocupacion"
                                        value="<?php echo e(old('ocupacion')); ?>" placeholder="Escriba la ocupación" required>
                                    <?php $__errorArgs = ['ocupacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Ingreso Mensual-->
                                <div class="col-md-7 mb-2">
                                    <label class="form-label <?php $__errorArgs = ['ingreso_mensual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold"
                                        for="ingreso_mensual">Ingreso Mensual</label>
                                    <div class="input-group">
                                        <div class="input-group-text">Bs.</div>
                                        <input type="number" class="form-control" id="ingreso_mensual"
                                            placeholder="Digite en Bs." name="ingreso_mensual"
                                            value="<?php echo e(old('ingreso_mensual')); ?>" min="0" required>
                                        <?php $__errorArgs = ['ingreso_mensual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!--Motivo de Consulta-->
                                <div class="col-md-12">
                                    <label for="motivo_consulta"
                                        class="form-label <?php $__errorArgs = ['motivo_consulta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Motivo
                                        de Consulta</label>
                                    <textarea class="form-control" id="motivo_consulta" name="motivo_consulta"
                                        placeholder="Describa el motivo de la consulta" rows="7" required><?php echo e(old('motivo_consulta')); ?></textarea>
                                    <?php $__errorArgs = ['motivo_consulta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END Card group-->

                <!--START Car Group 2-->
                <div class="card-group mb-3">
                    <div class="card shadow-sm border-0">
                        <div class="card-header text-center text-white fw-bold h4" style="background-color: #85c2d4">Entrevista Inicial</div>
                        
                        <div class="card-body">
                            <!--Entrevista Inicial-->
                            
                            <div class="row d-flex justify-content-between mb-2">
                                <!--Historia Familiar-->
                                <div class="col-md-12 mb-3">
                                    <label for="historia_familiar"
                                        class="form-label <?php $__errorArgs = ['historia_familiar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Historia
                                        Familiar</label>
                                    <textarea class="form-control" id="historia_familiar" name="historia_familiar"
                                        placeholder="Describa la historia familiar del paciente" rows="5" required><?php echo e(old('historia_familiar')); ?></textarea>
                                    <?php $__errorArgs = ['historia_familiar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Tipo de Familia-->
                                <div class="col-md-6 mb-2">
                                    <label for="tipo_familia"
                                        class="form-label <?php $__errorArgs = ['tipo_familia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Tipo de
                                        Familia</label>
                                    <select class="form-select" id="tipo_familia" name="tipo_familia" required>
                                        <option selected disabled value="">-- Seleccione --</option>
                                        <option value="Monoparental"
                                            <?php echo e(old('tipo_familia') == 'Monoparental' ? 'selected' : ''); ?>>Monoparental
                                        </option>
                                        <option value="Nuclear" <?php echo e(old('tipo_familia') == 'Nuclear' ? 'selected' : ''); ?>>
                                            Nuclear</option>
                                        <option value="Extensa" <?php echo e(old('tipo_familia') == 'Extensa' ? 'selected' : ''); ?>>
                                            Extensa</option>
                                        <option value="Ampliada"
                                            <?php echo e(old('tipo_familia') == 'Ampliada' ? 'selected' : ''); ?>>Ampliada</option>
                                        <option value="Reconstituida"
                                            <?php echo e(old('tipo_familia') == 'Reconstituida' ? 'selected' : ''); ?>>Reconstituida
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['tipo_familia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--Tipo-->
                                <div class="col-md-6 mb-2">
                                    <label for="sexo"
                                        class="form-label <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Tipo</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="tipo" id="funcional"
                                            value="funcional" <?php echo e(old('tipo') == 'funcional' ? 'checked' : ''); ?> required>
                                        <label class="form-check-label" for="funcional">Funcional</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="tipo" id="disfuncional"
                                            value="disfuncional" <?php echo e(old('tipo') == 'disfuncional' ? 'checked' : ''); ?>

                                            required>
                                        <label class="form-check-label" for="disfuncional">Disfuncional</label>
                                    </div>
                                    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Relación con los Familiares-->
                    <div class="card shadow-sm border-0">
                        <div class="card-header text-center text-white fw-bold h4" style="background-color: #85c2d4">Relación con los Familiares
                        </div>
                        <div class="card-body">
                            <div class="row justify-content-between">
                                <div class="col-md-6 mb-2">
                                    <div class="card">
                                        <div class="card-header text-center fst-italic text-muted" style="background-color: #eaeace">
                                            <span class="h6 <?php $__errorArgs = ['conyugal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Relación
                                                Conyugal</span>
                                        </div>
                                        <div class="card-body card-conyugal">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="conyugal"
                                                    id="estables" value="estables"
                                                    <?php echo e(old('conyugal') == 'estables' ? 'checked' : ''); ?> required>
                                                <label class="form-check-label" for="estables">Estables</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="conyugal"
                                                    id="estrecho" value="estrecho"
                                                    <?php echo e(old('conyugal') == 'estrecho' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="estrecho">Estrecho</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="conyugal"
                                                    id="distante" value="distante"
                                                    <?php echo e(old('conyugal') == 'distante' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="distante">Distante</label>
                                            </div>
                                            <div class="form-check form-check-inline m-0">
                                                <input class="form-check-input" type="checkbox" name="conyugal"
                                                    id="conflictivo" value="conflictivo"
                                                    <?php echo e(old('conyugal') == 'conflictivo' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="conflictivo">Conflictivo</label>
                                            </div>
                                            
                                            <div>
                                                <input type="text" class="form-control" id="otros-conyugal"
                                                    name="conyugal" value="<?php echo e(old('conyugal')); ?>"
                                                    placeholder="Otros...">
                                            </div>

                                            <?php $__errorArgs = ['conyugal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="bg-danger text-white my-1 rounded-3 small p-1 text-center">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="card">
                                        <div class="card-header text-center fst-italic text-muted" style="background-color: #eaeace">
                                            <span class="h6 <?php $__errorArgs = ['materno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Relación
                                                Materno-Filial</span>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="materno"
                                                    id="estables-materno" value="estables"
                                                    <?php echo e(old('materno') == 'estables' ? 'checked' : ''); ?> required>
                                                <label class="form-check-label" for="estables-materno">Estables</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="materno"
                                                    id="estrecho-materno" value="estrecho"
                                                    <?php echo e(old('materno') == 'estrecho' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="estrecho-materno">Estrecho</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="materno"
                                                    id="distante-materno" value="distante"
                                                    <?php echo e(old('materno') == 'distante' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="distante-materno">Distante</label>
                                            </div>
                                            <div class="form-check form-check-inline m-0">
                                                <input class="form-check-input" type="checkbox" name="materno"
                                                    id="conflictivo-materno" value="conflictivo"
                                                    <?php echo e(old('materno') == 'conflictivo' ? 'checked' : ''); ?>>
                                                <label class="form-check-label"
                                                    for="conflictivo-materno">Conflictivo</label>
                                            </div>
                                            
                                            <div>
                                                <input type="text" class="form-control" id="otros-materno"
                                                    name="materno" value="<?php echo e(old('materno')); ?>"
                                                    placeholder="Otros...">
                                            </div>

                                            <?php $__errorArgs = ['materno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="bg-danger text-white my-1 rounded-3 small p-1 text-center">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="card">
                                        <div class="card-header text-center fst-italic text-muted" style="background-color: #eaeace">
                                            <span class="h6 <?php $__errorArgs = ['paterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Relación
                                                Paterno-Filial</span>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="paterno"
                                                    id="estables-paterno" value="estables"
                                                    <?php echo e(old('paterno') == 'estables' ? 'checked' : ''); ?> required>
                                                <label class="form-check-label" for="estables-paterno">Estables</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="paterno"
                                                    id="estrecho-paterno" value="estrecho"
                                                    <?php echo e(old('paterno') == 'estrecho' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="estrecho-paterno">Estrecho</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="paterno"
                                                    id="distante-paterno" value="distante"
                                                    <?php echo e(old('paterno') == 'distante' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="distante-paterno">Distante</label>
                                            </div>
                                            <div class="form-check form-check-inline m-0">
                                                <input class="form-check-input" type="checkbox" name="paterno"
                                                    id="conflictivo-paterno" value="conflictivo"
                                                    <?php echo e(old('paterno') == 'conflictivo' ? 'checked' : ''); ?>>
                                                <label class="form-check-label"
                                                    for="conflictivo-paterno">Conflictivo</label>
                                            </div>
                                            
                                            <div>
                                                <input type="text" class="form-control" id="otros-paterno"
                                                    name="paterno" value="<?php echo e(old('paterno')); ?>"
                                                    placeholder="Otros...">
                                            </div>

                                            <?php $__errorArgs = ['paterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="bg-danger text-white my-1 rounded-3 small p-1 text-center">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <div class="card">
                                        <div class="card-header text-center fst-italic text-muted" style="background-color: #eaeace">
                                            <span class="h6 <?php $__errorArgs = ['fraterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">Relación
                                                Fraterno-Filial</span>
                                        </div>
                                        <div class="card-body">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="fraterno"
                                                    id="estables-fraterno" value="estables"
                                                    <?php echo e(old('fraterno') == 'estables' ? 'checked' : ''); ?> required>
                                                <label class="form-check-label" for="estables-fraterno">Estables</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="fraterno"
                                                    id="estrecho-fraterno" value="estrecho"
                                                    <?php echo e(old('fraterno') == 'estrecho' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="estrecho-fraterno">Estrecho</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" name="fraterno"
                                                    id="distante-fraterno" value="distante"
                                                    <?php echo e(old('fraterno') == 'distante' ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="distante-fraterno">Distante</label>
                                            </div>
                                            <div class="form-check form-check-inline m-0">
                                                <input class="form-check-input" type="checkbox" name="fraterno"
                                                    id="conflictivo-fraterno" value="conflictivo"
                                                    <?php echo e(old('fraterno') == 'conflictivo' ? 'checked' : ''); ?>>
                                                <label class="form-check-label"
                                                    for="conflictivo-fraterno">Conflictivo</label>
                                            </div>
                                            
                                            <div>
                                                <input type="text" class="form-control" id="otros-fraterno"
                                                    name="fraterno" value="<?php echo e(old('fraterno')); ?>"
                                                    placeholder="Otros...">
                                            </div>

                                            <?php $__errorArgs = ['fraterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="bg-danger text-white my-1 rounded-3 small p-1 text-center">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--END Card group-->

                <!--START Car Group 3-->
                <div class="card-group mb-3">
                    <div class="card shadow-sm border-0">
                        <div class="card-header text-center text-white fw-bold h4" style="background-color: #85c2d4">Conclusiones</div>
                        <div class="card-body">
                            <div class="row d-flex justify-content-between mb-3">
                                <div class="col-md-6 my-2">
                                    <label for="diagnostico_social"
                                        class="form-label <?php $__errorArgs = ['diagnostico_social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Diagnóstico
                                        Social:</label>
                                    <textarea id="diagnostico_social" name="diagnostico_social" class="form-control"
                                        placeholder="Describa el diagnóstico social..." style="height: 120px" required><?php echo e(old('diagnostico_social')); ?></textarea>
                                    <?php $__errorArgs = ['diagnostico_social'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 my-2">
                                    <label for="acciones"
                                        class="form-label <?php $__errorArgs = ['acciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> fw-bold">Acciones a
                                        Seguir:</label>
                                    <textarea id="acciones" name="acciones" class="form-control"
                                        placeholder="Describa todas las acciones vea conveniente" style="height: 120px" required><?php echo e(old('acciones')); ?></textarea>
                                    <?php $__errorArgs = ['acciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-center justify-content-md-end bg-transparent">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-danger mx-2 fw-bolder"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
                <button type="submit" class="btn btn-success fw-bolder" id="submit"><i class="fa-solid fa-circle-check"></i> Guardar Caso</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

    <!-- JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>

    <script>
        if ($("#formPacientes").length > 0) {
            $("#formPacientes").validate({

                rules: {
                    caso: {
                        required: true,
                        maxlength: 5,
                        remote: {
                            url: "<?php echo e(route('paciente.validar.caso')); ?>",
                            type: "GET",
                            data: {
                                caso: function() {
                                    return $("input[name='caso']").val();
                                }
                            },
                            dataFilter: function(data) {
                                var json = JSON.parse(data);
                                if (json.msg == "true") {
                                    return "\"" + "El número de caso ya existe, digite otro por favor." + "\"";
                                } else {
                                    return 'true';
                                }
                            }
                        }
                    },
                    fecha: {
                        required: true
                    },
                    hora: {
                        required: true
                    },
                    nombres: {
                        required: true,
                        maxlength: 70
                    },
                    edad: {
                        required: true,
                        maxlength: 2
                    },
                    sexo: {
                        required: true
                    },
                    direccion: {
                        required: true,
                        maxlength: 250
                    },
                    telefono: {
                        required: true,
                        maxlength: 8,
                        minlength: 8
                    },
                    telefono_referencia: {
                        required: true,
                        maxlength: 8,
                        minlength: 8
                    },
                    estado_civil: {
                        required: true
                    },
                    anios: {
                        required: true,
                        maxlength: 3
                    },
                    nombre_esposo: {
                        required: true,
                        maxlength: 70
                    },
                    edad_esposo: {
                        required: true,
                        maxlength: 2
                    },
                    grado_instruccion: {
                        required: true
                    },
                    cantidad_hijos: {
                        required: true,
                        maxlength: 2
                    },
                    ocupacion: {
                        required: true,
                        maxlength: 30
                    },
                    ingreso_mensual: {
                        required: true,
                        maxlength: 6
                    },
                    motivo_consulta: {
                        required: true,
                        maxlength: 250
                    },
                    historia_familiar: {
                        required: true,
                        maxlength: 250
                    },
                    tipo_familia: {
                        required: true
                    },
                    tipo: {
                        required: true
                    },
                    conyugal: {
                        required: false,
                        //required: true
                    },
                    materno: {
                        required: false,
                        //required: true
                    },
                    paterno: {
                        required: false,
                        //required: true
                    },
                    fraterno: {
                        required: false,
                        //required: true
                    },
                    diagnostico_social: {
                        required: true,
                        maxlength: 250
                    },
                    acciones: {
                        required: true,
                        maxlength: 250
                    },
                },

                messages: {
                    caso: {
                        required: "Por favor introduzca el número de caso.",
                        maxlength: "El caso no debe superar los 5 dígitos.",
                        //remote: "El número de caso ya existe."
                    },
                    fecha: {
                        required: "Por favor indique la fecha.",
                    },
                    hora: {
                        required: "Por favor indique la hora.",
                    },
                    nombres: {
                        required: "Por favor escriba el nombre completo.",
                        maxlength: "El nombre no debe superar los 70 caracteres",
                    },
                    edad: {
                        required: "Por favor digite la edad.",
                        maxlength: "La edad no debe pasar los 2 dígitos.",
                    },
                    sexo: {
                        required: "Por favor seleccione una opción.",
                    },
                    direccion: {
                        required: "Por favor escriba la dirección.",
                        maxlength: "Trate que no sobrepase los 250 caracteres",
                    },
                    telefono: {
                        required: "Por favor digite el teléfono",
                        minlength: "El teléfono debe tener al menos 8 dígitos",
                        maxlength: "El teléfono no debe pasar los 8 dígitos.",
                    },
                    telefono_referencia: {
                        required: "Por favor digite el número de referencia",
                        minlength: "El teléfono debe tener al menos 8 dígitos",
                        maxlength: "El número de referencia no debe pasar los 8 dígitos.",
                    },
                    estado_civil: {
                        required: "Por favor seleccione una opción.",
                    },
                    anios: {
                        required: "Por favor indique los años.",
                        maxlength: "La edad no debe pasar los 2 dígitos.",
                    },
                    nombre_esposo: {
                        required: "Por favor escriba el nombre completo",
                        maxlength: "El nombre no debe superar los 70 caracteres",
                    },
                    edad_esposo: {
                        required: "Por favor digite la edad del esposo(a).",
                        maxlength: "La edad no debe pasar los 2 dígitos.",
                    },
                    grado_instruccion: {
                        required: "Por favor seleccione una opción.",
                    },
                    cantidad_hijos: {
                        required: "Por favor digite la cantidad de hijos.",
                        maxlength: "La cantidad no debe pasar los 2 dígitos.",
                    },
                    ocupacion: {
                        required: "Por favor escriba la ocupación.",
                        maxlength: "Trate que no sobrepase los 30 caracteres",
                    },
                    ingreso_mensual: {
                        required: "Por favor digite el ingreso mensual en números.",
                        maxlength: "El monto no debe superar los 6 dígitos.",
                    },
                    motivo_consulta: {
                        required: "Por favor describa el motivo de la consulta.",
                        maxlength: "La descripción no debe superar los 300 caracteres",
                    },
                    historia_familiar: {
                        required: "Por favor describa la historia familiar.",
                        maxlength: "La descripción no debe superar los 350 caracteres",
                    },
                    tipo_familia: {
                        required: "Por favor seleccione una opción.",
                    },
                    tipo: {
                        required: "Por favor seleccione una opción.",
                    },
                    conyugal: {
                        required: "Por favor seleccione una opción.",
                    },
                    materno: {
                        required: "Por favor seleccione una opción.",
                    },
                    paterno: {
                        required: "Por favor seleccione una opción.",
                    },
                    fraterno: {
                        required: "Por favor seleccione una opción.",
                    },
                    diagnostico_social: {
                        required: "Por favor describa el diagnóstico social.",
                        maxlength: "La descripción no debe superar los 350 caracteres",
                    },
                    acciones: {
                        required: "Por favor describa las acciones a tomar.",
                        maxlength: "La descripción no debe superar los 350 caracteres",
                    },
                },
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pacientes/create.blade.php ENDPATH**/ ?>