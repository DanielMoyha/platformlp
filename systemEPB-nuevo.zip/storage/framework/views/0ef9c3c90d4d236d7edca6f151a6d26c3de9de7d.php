

<?php $__env->startSection('titulo'); ?>
    Perfil
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Datos Personales</li>
    </ol>

    

    <div class="card shadow border-0 rounded-3 mb-5">
        <div class="row">
        <div class="col-md-4 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <?php if(auth()->user()->role_id != 1): ?>
                    <img class="mt-md-5" width="150px" src="<?php echo e(asset('img/doc-personales.svg')); ?>">
                <?php else: ?>
                    <img class="mt-md-5" width="150px" src="<?php echo e(asset('img/doc-personales-ts.svg')); ?>">
                <?php endif; ?>
                <span class="font-weight-bold"><?php echo e(auth()->user()->role->name); ?></span>
                <span class="text-black-50"><?php echo e(auth()->user()->email); ?></span>
                <span></span>
            </div>
        </div>
        <div class="col-md-5 border-right">
            <div class="p-3 py-md-5">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    
                    <ul class="nav nav-tabs nav-tabs-custom nav-justified justify-content-center faq-tab-box" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a href="#datos_personales" class="nav-link active" id="pills-genarel-tab" data-bs-toggle="pill" role="tab" aria-controls="pills-genarel" aria-selected="true">
                                <h5 class="mb-0"><i class="fa-solid fa-user"></i> Datos personales</h5>
                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a href="#cambiar_contrasenia" class="nav-link" id="pills-privacy_policy-tab" data-bs-toggle="pill" role="tab" aria-controls="pills-privacy_policy" aria-selected="false">
                                <h5 class="mb-0"><i class="fa-solid fa-key"></i> Cambiar Contraseña</h5>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content" id="pills-tabContent">
                    <!-- DATOS PERSONALES -->
                    <div class="tab-pane fade active show" id="datos_personales" role="tabpanel" aria-labelledby="pills-tab">
                        <form action="<?php echo e(route('profile.update', $user->id)); ?>" method="POST">
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row mt-1">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label fw-bold-600 fst-italic">Nombre</label>
                                    <input
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="name"
                                        id="name"
                                        placeholder="Escriba su Nombre"
                                        value="<?php echo e(old('name', $user->name)); ?>"
                                    />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold-600 fst-italic">Nombre de Usuario</label>
                                    <input
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="username"
                                        id="username"
                                        placeholder="Escriba su nombre de usuario"
                                        value="<?php echo e(old('username', $user->username)); ?>"
                                    />
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fw-bold-600 fst-italic">Correo Electrónico</label>
                                    <input
                                        type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email"
                                        id="email"
                                        placeholder="Escriba su correo electrónico"
                                        value="<?php echo e(old('email', $user->email)); ?>"
                                    />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fw-bold-600 fst-italic">Dirección</label>
                                    <input
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Escriba su dirección"
                                        name="direccion"
                                        id="direccion"
                                        value="<?php echo e(old('direccion', $user->direccion)); ?>"
                                    />
                                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold-600 fst-italic">Teléfono</label>
                                    <input
                                        type="number"
                                        class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Digite su teléfono"
                                        name="telefono"
                                        id="telefono"
                                        value="<?php echo e(old('telefono', $user->telefono)); ?>"
                                    />
                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold-600 fst-italic">Carnét de Identidad</label>
                                    <input
                                        type="text"
                                        class="form-control <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Escriba su C.I."
                                        name="ci"
                                        id="ci"
                                        value="<?php echo e(old('ci', $user->ci)); ?>"
                                    />
                                    <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mt-3 text-center">
                                <button class="btn btn-success profile-button fw-bolder" type="submit"><i class="fa-solid fa-circle-check"></i> Guardar Datos</button>
                                <a href="<?php echo e(route('profile')); ?>" class="btn btn-danger fw-bolder m-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>

                            </div>
                        </form>
                    </div>

                    <!-- CAMBIAR CONTRASEÑA -->
                    <div class="tab-pane fade" id="cambiar_contrasenia" role="tabpanel" aria-labelledby="pills-tab">
                        <form action="<?php echo e(route('update-password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                

                                <div class="mb-3">
                                    <label for="password" class="form-label fw-bold-600 fst-italic">Contraseña Actual</label>
                                    <div class="input-group">
                                        <input
                                            id="password"
                                            name="old_password"
                                            type="password"
                                            class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="Escriba su Contraseña Actual"
                                        >
                                        <span class="input-group-text" onclick="password_show_hide();" role="button">
                                            <i class="fas fa-eye" id="show_eye"></i>
                                            <i class="fas fa-eye-slash d-none" id="hide_eye"></i>
                                        </span>
                                    </div>
                                    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--NEW PASSWORD-->
                                <div class="mb-3">
                                    <label for="newPasswordInput" class="form-label fw-bold-600 fst-italic">Nueva Contraseña</label>
                                    <div class="input-group">
                                        <input name="new_password" type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="newPasswordInput"
                                            placeholder="Escriba su Nueva Contraseña">
                                        <span class="input-group-text" onclick="newPassword_show_hide();" role="button">
                                            <i class="fas fa-eye" id="show_eye_n"></i>
                                            <i class="fas fa-eye-slash d-none" id="hide_eye_n"></i>
                                        </span>
                                    </div>
                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!--CONFIRM NEW PASSWORD-->
                                <div class="mb-3">
                                    <label for="confirmNewPasswordInput" class="form-label fw-bold-600 fst-italic">Confirmar Nueva Contraseña</label>
                                    <div class="input-group">
                                        <input name="new_password_confirmation" type="password" class="form-control" id="confirmNewPasswordInput"
                                        placeholder="Vuelva a escribir su Nueva Contraseña">
                                        <span class="input-group-text" onclick="confirmNewPassword_show_hide();" role="button">
                                            <i class="fas fa-eye" id="show_eye_c"></i>
                                            <i class="fas fa-eye-slash d-none" id="hide_eye_c"></i>
                                        </span>
                                    </div>
                                </div>
    
                            </div>
    
                            <div class="mt-2 text-center">
                                <button class="btn btn-success fw-bold"><i class="fa-solid fa-circle-check"></i> Actualizar Contraseña</button>
                                <a href="<?php echo e(route('profile')); ?>" class="btn btn-danger fw-bold m-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
                            </div>
    
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
        function password_show_hide() {
            let oldPassword = document.getElementById("password");
            let show_eye = document.getElementById("show_eye");
            let hide_eye = document.getElementById("hide_eye");

            hide_eye.classList.remove("d-none");

            if (oldPassword.type === "password")
            {
                oldPassword.type = "text";
                show_eye.style.display = "none";
                hide_eye.style.display = "block";
            } else {
                oldPassword.type = "password";
                show_eye.style.display = "block";
                hide_eye.style.display = "none";
            }
        }

        function newPassword_show_hide() {
            let newPassword = document.getElementById("newPasswordInput");
            let show_eye = document.getElementById("show_eye_n");
            let hide_eye = document.getElementById("hide_eye_n");
            hide_eye.classList.remove("d-none");

            if (newPassword.type === "password")
            {
                newPassword.type = "text";
                show_eye.style.display = "none";
                hide_eye.style.display = "block";
            } else {
                newPassword.type = "password";
                show_eye.style.display = "block";
                hide_eye.style.display = "none";
            }
        }

        function confirmNewPassword_show_hide() {
            let confirmNewPassword = document.getElementById("confirmNewPasswordInput");
            let show_eye = document.getElementById("show_eye_c");
            let hide_eye = document.getElementById("hide_eye_c");
            hide_eye.classList.remove("d-none");

            if (confirmNewPassword.type === "password")
            {
                confirmNewPassword.type = "text";
                show_eye.style.display = "none";
                hide_eye.style.display = "block";
            } else {
                confirmNewPassword.type = "password";
                show_eye.style.display = "block";
                hide_eye.style.display = "none";
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/profile/edit-profile.blade.php ENDPATH**/ ?>