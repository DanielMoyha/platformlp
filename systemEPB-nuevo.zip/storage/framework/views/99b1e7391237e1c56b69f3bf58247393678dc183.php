

<?php $__env->startSection('titulo'); ?>
    Perfil
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Datos Personales</li>
    </ol>

    <div class="card mb-3 shadow">
        
        <div class="row">
            
            <div class="col-md-4 shadow-sm">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <?php if(auth()->user()->role_id != 1): ?>
                        <img class="mt-md-5" width="150px" src="<?php echo e(asset('img/doc-personales.svg')); ?>">
                    <?php else: ?>
                        <img class="mt-md-5" width="150px" src="<?php echo e(asset('img/doc-personales-ts.svg')); ?>">
                    <?php endif; ?>
                    <span class="font-weight-bold"><?php echo e(auth()->user()->role->name); ?></span>
                    <span class="text-black-50"><?php echo e(auth()->user()->email); ?></span>
                    <span></span>
                </div>
            </div>
            <div class="col-md-5 shadow-sm">
                <div class="p-3 py-md-5">
                    <div>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fa-solid fa-circle-check"></i> <?php echo e(session('status')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php elseif(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h3 class="text-right">Perfil Personal</h4>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-6 mb-3">
                            <!--<label class="form-label">Nombre</label>-->
                            <label class="form-label">Nombre</label>
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Aún no proporcionó su Nombre"
                                value="<?php echo e(auth()->user()->name); ?>"
                                readonly
                            />
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nombre de Usuario</label>
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Sin Username"
                                value="<?php echo e(auth()->user()->username); ?>"
                                readonly
                            >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Dirección</label>
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Aún no proporcionó su dirección"
                                value="<?php echo e(auth()->user()->direccion); ?>"
                                readonly
                            >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Teléfono</label>
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Sin teléfono"
                                value="<?php echo e(auth()->user()->telefono); ?>"
                                readonly
                            >
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Carnét de Identidad</label>
                            <input
                                type="text"
                                class="form-control"
                                placeholder="Sin C.I."
                                value="<?php echo e(auth()->user()->ci); ?>"
                                readonly
                            >
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <a class="btn btn-warning profile-button" href="<?php echo e(route('psicologo.profile.edit', auth()->user()->id)); ?>">
                            Editar Datos
                        </a>
                         <a href="<?php echo e(route('casos.list')); ?>" class="btn btn-danger m-2">Volver</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard_Psico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/psicologo/profile/profile.blade.php ENDPATH**/ ?>