

<?php $__env->startSection('titulo'); ?>
    Administración
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.3.0/css/responsive.bootstrap5.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable.css')); ?>">
    <style>
        .error {
          color: #ca0505;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Usuarios</li>
    </ol>
    <div class="row mb-3">
        <div class="col-md-8">
            <a href="<?php echo e(route('personal')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-tie mx-1"></i> Ver Administrativos</a>
            <a href="<?php echo e(route('pasante')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-clock mx-1"></i> Ver Pasantes</a>
            <a href="<?php echo e(route('voluntario')); ?>" class="btn btn-secondary mt-2 mt-md-0"><i class="fa-solid fa-user-gear mx-1"></i> Ver Voluntarios</a>
        </div>
    </div>

    <!-- Datatable -->
    <div class="card mb-5 shadow table-administrativos">
        <div class="card-header d-md-flex justify-content-between bg-info">
            <div class="my-2">
                <i class="fas fa-table me-1"></i>
                <span class="h5 text-dark">Listado del Personal de la Institución</span>
            </div>
            <div class="">
                <a href="<?php echo e(route('personal.create')); ?>" class="btn btn-success fw-bold"><i class="fa-solid fa-circle-plus"></i> Registrar Nuevo</a>
            </div>
        </div>
        <div class="card-body">
            <table id="datatablePersonal" class="table table-striped dt-responsive order-column">
                <thead>
                    <tr>
                        <th></th>
                        <th>Estado</th>
                        <th>Nombres</th>
                        <th>Usuario</th>
                        <th>Carnét de Identidad</th>
                        <th>Cargo</th>
                        <th>Teléfono</th>
                        <th>Correo Electrónico</th>
                        <th>Dirección</th>

                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th></th>
                        <th>Estado</th>
                        <th>Nombres</th>
                        <th>Usuario</th>
                        <th>Carnét de Identidad</th>
                        <th>Cargo</th>
                        <th>Teléfono</th>
                        <th>Correo Electrónico</th>
                        <th>Dirección</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="form-check form-switch">
                                    <input data-id="<?php echo e($user->id); ?>" class="form-check-input mi_checkbox"
                                    type="checkbox" data-onstyle="success" data-offstyle="danger"
                                    data-toggle="toggle" data-on="Active" data-off="InActive"
                                    <?php echo e($user->estado ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                                </div>
                            </td>
                            <td id="resp<?php echo e($user->id); ?>">
                                <?php if($user->estado == 0 || empty($user->estado) || $user->estado == null): ?>
                                    <span class="badge bg-danger">Inactivo</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Activo</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->name) || $user->name == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->name); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->username) || $user->username == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->username); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->ci) || $user->ci == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin C.I.
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->ci); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->role->name) || $user->role->name == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->role->name); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->telefono) || $user->telefono == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->telefono); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->email) || $user->email == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Teléfono
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->email); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(empty($user->direccion) || $user->direccion == null): ?>
                                    <small class="bg-secondary rounded text-white-50 p-1 fst-italic">
                                        Sin Dirección
                                    </small>
                                <?php else: ?>
                                    <?php echo e($user->direccion); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.3.0/js/responsive.bootstrap5.min.js"></script>

    
    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('.mi_checkbox').change(function() {
                //Verifica el estado del checkbox, si esta seleccionado sera igual a 1 de lo contrario sera igual a 0
                var estado = $(this).prop('checked') == true ? 1 : 0;
                var id = $(this).data('id');
                //console.log(estado);
                $.ajax({
                    type: "GET",
                    dataType: "json",
                    //url: '/StatusNoticia',
                    url: '<?php echo e(route('personal.estado')); ?>',
                    data: {
                        'estado': estado,
                        'id': id
                    },
                    success: function(data) {
                        $('#resp' + id).html(data.var);
                        //console.log(data.var)
                    }
                });
            });
        });
    </script>

    

    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/personal/index.blade.php ENDPATH**/ ?>