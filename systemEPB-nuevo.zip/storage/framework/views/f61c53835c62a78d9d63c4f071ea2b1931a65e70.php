

<?php $__env->startSection('titulo'); ?>
    Registro de Hijos(as)
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Registre los datos de los hijos del caso que seleccionó</li>
    </ol>

    <div class="card shadow border-0 mb-4">
        <div class="card-header text-white text-center bg-info fw-bold h5"><i class="fa-solid fa-clipboard-list"></i> Datos del Caso</div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <label class="form-label fw-bold-600"><i class="fa-solid fa-hashtag"></i> Número de Caso: </label>
                    <span class="text-muted fst-italic"><?php echo e($paciente->caso); ?></span>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold-600"><i class="fa-solid fa-children"></i> Cantidad de Hijos: </label>
                    <span class="text-muted fst-italic fw-bold"><?php echo e($paciente->cantidad_hijos); ?> hijos(as)</span>
                    <input
                        type="hidden"
                        class="form-control"
                        id="cantidad_hijos"
                        name="cantidad_hijos"
                        min="0"
                        placeholder="Introduzca la cantidad de Hijos que tiene"
                        value="<?php echo e($paciente->cantidad_hijos); ?>"
                        disabled
                    />
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label class="form-label fw-bold-600">
                        <i class="fa-solid fa-address-card"></i> Nombre Completo <span class="text-muted fst-italic">(Padres o Tutores)</span>:
                    </label>
                </div>
                <div class="col-md-6">
                    <ul>
                        <li class="text-muted fst-italic"><?php echo e($paciente->nombres); ?></li>
                        <li class="text-muted fst-italic"><?php echo e($paciente->nombre_esposo); ?></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold-600"><i class="fa-solid fa-highlighter"></i> Diagnóstico Social: </label>
                    <div class="text-muted fst-italic"><?php echo e($paciente->diagnostico_social); ?></div>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold-600"><i class="fa-solid fa-file-lines"></i> Motivo de la Consulta: </label>
                    <div class="text-muted fst-italic"><?php echo e($paciente->motivo_consulta); ?></div>
                </div>
            </div>
        </div>
    </div>


        <!--START Card Group 2 - Hijos -->
        
        
        <div class="card shadow border-0 rounded-3 mb-5">
            <div class="card-header text-center text-white fw-bold h4" style="background-color: #47908b">Formulario de Registro para Hijos</div>

            <?php if($paciente->cantidad_hijos == 0): ?>
                <div class="alert alert-warning shadow-sm mx-4 mt-4" role="alert">
                    <h4 class="alert-heading"><i class="fa-solid fa-circle-exclamation"></i> Aviso</h4>
                    <p>Usted no puede registrar a los hijos, porque este <strong>caso tiene <?php echo e($paciente->cantidad_hijos); ?> hijos.</strong> Si piensa que es un error, por favor modifique la <span class="fst-italic">cantidad de hijos</span> que tiene este caso <a href="<?php echo e(route('paciente.edit', [$paciente->id])); ?>">(N° <?php echo e($paciente->caso); ?>)</a> para poder registrar los datos que desea.</p>
                </div>
                <div class="text-end mb-3">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-danger fw-bold-600 mx-2"><i class="fa-solid fa-arrow-left"></i> Volver</a>
                </div>
            <?php else: ?>
                <form action="<?php echo e(route('paciente.hijos.store')); ?>" method="POST" autocomplete="off">
                    <?php echo csrf_field(); ?>

                    <div class="row d-flex justify-content-start" id="content-hijos"></div>

                    <div class="card-footer d-flex align-items-center justify-content-end bg-transparent">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-danger fw-bold mx-2"><i class="fa-solid fa-circle-xmark"></i> Cancelar</a>
                        <button type="submit" class="btn btn-success fw-bold" id="submit"><i class="fa-solid fa-circle-check"></i> Guardar</button>
                    </div>
                </form>

            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            
            
            /** Generar campos por la cantidad de hijos */
            $(function () {
                $("#cantidad_hijos").keyup(function () {
                    let cantidad = $("#cantidad_hijos").val();
                    RenderInputs(cantidad);
                }).trigger('keyup');
            });

            function RenderInputs(cantidad) {
                $("#content-hijos").html("");

                for (let i = 0; i < cantidad; i++) {
                    // $("#content-hijos").append('<form class="form">');
                    $("#content-hijos").append(`
                        <div class="card-group mb-3">
                            <div class="card shadow">
                                <div class="card-body d-md-flex justify-content-around">
                                    <input name="paciente_id[]" type="text" value="<?php echo e($paciente->id); ?>" hidden>
                                    <div class="col-md-4 mb-2">
                                        <label
                                            for="nombre_hijo` + (i + 1) +`"
                                            class="form-label fw-bold">
                                                Nombre del Hijo(a)
                                        </label>

                                        <input
                                            type="text"
                                            class="form-control <?php $__errorArgs = ['nombre[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="nombre_hijo` + (i + 1) +`"
                                            name="nombre[]
                                            value="<?php echo e(old('nombre[]')); ?>"
                                            placeholder="Nombre Completo de su hijo(a)"
                                            required
                                        />
                                        <?php $__errorArgs = ['nombre[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-2 mb-2">
                                        <label
                                            for="edad_hijo` + (i + 1) +`"
                                            class="form-label fw-bold">
                                                Edad
                                        </label>
                                        <input
                                            type="number"
                                            class="form-control <?php $__errorArgs = ['edad[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="edad_hijo` + (i + 1) +`"
                                            name="edad[]"
                                            min="0"
                                            value="<?php echo e(old('edad[]')); ?>"
                                            placeholder="Edad del hijo(a)"
                                            required
                                        />
                                        <?php $__errorArgs = ['edad[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
        
                                    <div class="col-md-2 mb-2">
                                        <label for="sexo-hijo`+(i + 1)+`" class="form-label fw-bold">Sexo</label>
                                        <select class="form-select <?php $__errorArgs = ['sexo[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sexo-hijo` + (i + 1) + `" name="sexo[]" required>
                                            <option selected disabled>-- Seleccione --</option>
                                            <option value="Masculino" <?php echo e(old('sexo[]') == 'Masculino' ? 'selected' : ''); ?>>Masculino</option>
                                            <option value="Femenino" <?php echo e(old('sexo[]') == 'Femenino' ? 'selected' : ''); ?>>Femenino</option>
                                        </select>
                                        <?php $__errorArgs = ['sexo[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-2 mb-2">
                                        <label for="user_id` +(i + 1) +`" class="form-label fw-bold">Encargada:</label>
                                        <select name="user_id[]" class="form-control <?php $__errorArgs = ['user_id[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="user_id` + (i + 1) + `">
                                            <option value="" class="text-muted">* Sin Encargada *</option>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id[]') == '$user->id' ? 'selected' : ''); ?>>
                                                    <?php echo e($user->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['user_id[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="bg-danger text-white my-2 rounded-lg text-sm p-2 text-center">
                                                <?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `);
                }
            }
            $(function(){
                $('div[onload]').trigger('onload');
            });
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pacientes/show.blade.php ENDPATH**/ ?>