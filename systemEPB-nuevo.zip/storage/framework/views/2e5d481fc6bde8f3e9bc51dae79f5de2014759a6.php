<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="<?php echo e(asset('img/icon.png')); ?>" type="image/x-icon">
    <title>EPB - <?php echo $__env->yieldContent('titulo'); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Scripts -->

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed" style="background-color: #fafafc">
    
    <nav class="sb-topnav navbar navbar-expand navbar-dark" style="background-color: #202942; !important">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="<?php echo e(route('home')); ?>">
            E.P.B - La Paz
        </a>

        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Navbar Search-->
        <div class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-1 my-2 my-md-0">
            
            <span class="fw-bold text-muted">Bienvenido(a):</span>
        </div>

        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false"><?php echo e(Auth::user()->name); ?><i
                        class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end text-center" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><span class="fw-bold">Ver Perfil</span> <i class="fa-solid fa-user-gear icon-info"></i></a></li>
                    
                    <li>
                        <hr class="dropdown-divider" />
                    </li>

                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><span class="fw-bold">Salir <i class="fa-solid fa-right-from-bracket icon-danger"></i> </span>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion" style="background-color: #202942; !important">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Control</div>
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Panel Administrativo
                        </a>
                        <div class="sb-sidenav-menu-heading">Usuarios</div>
                        
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Personal
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('personal')); ?>"><i class="fas fa-table px-2"></i> Ver lista</a>
                                
                                <a class="nav-link collapsed pt-md-0" href="#" data-bs-toggle="collapse"
                                    data-bs-target="#collapseLayouts2" aria-expanded="false" aria-controls="collapseLayouts2">
                                    <div class="sb-nav-link-icon"><i class="fa-solid fa-user-plus"></i></div>
                                    Agregar Personal
                                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                                </a>

                                <div class="collapse" id="collapseLayouts2" aria-labelledby="headingOne"
                                    data-bs-parent="#sidenavAccordion2">
                                    <nav class="sb-sidenav-menu-nested nav">
                                        <a class="nav-link pt-md-0" href="<?php echo e(route('personal.create')); ?>"><i class="fa-solid fa-user-tie px-2"></i>Administrativos</a>
                                        <a class="nav-link pt-md-0" href="<?php echo e(route('pasante.create')); ?>"><i class="fa-solid fa-user-clock px-2"></i>Pasantes</a>
                                        <a class="nav-link pt-md-0" href="<?php echo e(route('voluntario.create')); ?>"><i class="fa-solid fa-user-gear px-2"></i>Voluntarios</a>
                                    </nav>
                                </div>
                            </nav>
                        </div>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseCasos" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-briefcase"></i></div>
                            Casos
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseCasos" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house-circle-check px-2"></i>Ver Casos</a>
                                <a class="nav-link" href="<?php echo e(route('paciente.create')); ?>"><i class="fa-solid fa-file-circle-plus px-2"></i></i>Registrar Nuevo Caso</a>
                                <a class="nav-link" href="<?php echo e(route('hijos')); ?>"><i class="fa-solid fa-clipboard-list px-2"></i></i></i>Ver Asignaciones</a>
                            </nav>
                        </div>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseSeguimiento" aria-expanded="false" aria-controls="collapseSeguimiento">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-bars-progress"></i></div>
                            Seguimiento
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseSeguimiento" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('seguimiento.sesiones')); ?>"><i class="fa-solid fa-id-card px-2"></i> Sesiones</a>
                            </nav>
                        </div>

                        
                        
                    </div>
                </div>
                <div class="sb-sidenav-footer" style="background-color: #202942; !important">
                    <div class="small fst-italic">Conectado como:</div>
                    <?php echo e(auth()->user()->role->name); ?>

                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h2 class="mt-4"><?php echo $__env->yieldContent('titulo'); ?></h2>
                    <?php echo $__env->yieldContent('content'); ?>

                </div>
            </main>


            <footer class="py-4 mt-auto footer-dash">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; EPB Filial - LA PAZ <?php echo e(now()->year); ?></div>
                        
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/dashboard.js')); ?>" defer></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    
        
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>