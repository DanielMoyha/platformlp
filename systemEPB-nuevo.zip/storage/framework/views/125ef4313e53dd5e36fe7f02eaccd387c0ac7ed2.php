

<?php $__env->startSection('titulo'); ?>
    Nuevo Caso
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <!-- CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />

    <style>
        .error{
        color: #FF0000; 
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Crear</li>
    </ol>
    
    <form action="<?php echo e(route('paciente.update',$paciente->id)); ?>" method="POST" >
        <?php echo method_field('patch'); ?>
        <?php echo csrf_field(); ?>
        
        <!--Card group-->
        <div class="card-group mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="row d-flex justify-content-between mb-3">
                        <!--N° Caso-->
                        <div class="col-md-12 mb-2">
                            <label class="visually-hidden" for="caso">Caso</label>
                            <div class="input-group">
                                <div class="input-group-text">N° Caso</div>
                                <input
                                    type="number"
                                    class="form-control"
                                    id="caso"
                                    placeholder="Número de caso"
                                    name="caso"
                                    min="0"
                                    required
                                    value="<?php echo e($paciente->caso); ?>"
                                />
                            </div>
                        </div>

                        <!--Fecha-->
                        <div class="col-md-7 mb-2">
                            <label class="form-label" for="fecha">Fecha</label>
                            <div class="input-group">
                                
                                <input
                                    type="date"
                                    class="form-control"
                                    id="fecha"
                                    name="fecha"
                                    required
                                    value="<?php echo e($paciente->fecha); ?>"
                                >
                                
                            </div>
                        </div>

                        <!--Hora-->
                        <div class="col-md-5 mb-2">
                            <label class="form-label" for="hora">Hora</label>
                            <div class="input-group">
                                
                                <input type="time" class="form-control" id="hora" name="hora" required value="<?php echo e($paciente->hora); ?>">
                                
                            </div>
                        </div>
                        <hr>
                    </div>

                    <div class="row d-flex justify-content-between mb-3">
                        <!--Nombre Completo-->
                        <div class="col-md-12 mb-2">
                            <label for="nombres" class="form-label fw-bold">Nombres y Apellidos</label>
                            <input type="text" class="form-control" id="nombres" name="nombres"
                                placeholder="Nombre Completo" value="<?php echo e($paciente->nombres); ?>" required>
                            
                        </div>

                        <!--Edad-->
                        <div class="col-md-4 mb-2">
                            <label for="edad" class="form-label fw-bold">Edad</label>
                            <input type="number" class="form-control" id="edad" name="edad" min="0"
                                placeholder="Edad" value="<?php echo e($paciente->edad); ?>" required>
                            
                        </div>

                        <!--Sexo-->
                        <div class="col-md-8 mb-2 p-md-0">
                            <label for="sexo" class="form-label fw-bold">Sexo</label><br>
                            <div class="form-check form-check-inline">
                                <input
                                    class="form-check-input sexo"
                                    type="radio"
                                    name="sexo"
                                    id="masculino"
                                    value="1"
                                    <?php echo e($paciente->sexo == '0' ? 'checked' : ''); ?>

                                    required
                                >
                                <label class="form-check-label" for="masculino">Masculino</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input
                                    class="form-check-input sexo"
                                    type="radio"
                                    name="sexo"
                                    id="femenino"
                                    value="0"
                                    <?php echo e($paciente->sexo == '1' ? 'checked' : ''); ?>

                                >
                                <label class="form-check-label" for="femenino">Femenino</label>
                            </div>
                        </div>

                        <!--Dirección-->
                        <div class="col-md-12 mb-2">
                            <label for="direccion" class="form-label fw-bold">Dirección</label>
                            <textarea class="form-control" id="direccion" name="direccion" placeholder="Escriba la dirección" required><?php echo e($paciente->direccion); ?></textarea>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row d-flex justify-content-between mb-3">
                        <!--Teléfono-->
                        <div class="col-md-6 mb-2">
                            <label for="telefono" class="form-label">Teléfono</label>
                            <input type="number" class="form-control" id="telefono" name="telefono" placeholder="00000000" value="<?php echo e($paciente->telefono); ?>" required>
                            
                        </div>

                        <!--Número de Referencia-->
                        <div class="col-md-6 mb-2">
                            <label for="telefono_referencia" class="form-label">Num. Referencia</label>
                            <input type="number" class="form-control" id="telefono_referencia"
                                name="telefono_referencia" placeholder="00000000" value="<?php echo e($paciente->telefono_referencia); ?>" required>
                            
                        </div>

                        <!--Estado Civil-->
                        <div class="col-md-6 mb-2">
                            <label for="estado_civil" class="form-label">Estado Civil</label>
                            <select class="form-select" id="estado_civil" name="estado_civil" required>
                                <option selected disabled value="">-- Seleccione --</option>
                                <option value="casado" <?php echo e($paciente->estado_civil == 'casado' ? 'selected' : ''); ?>>Casado</option>
                                <option value="Viudo" <?php echo e($paciente->estado_civil == 'Viudo' ? 'selected' : ''); ?>>Viudo</option>
                                <option value="Divorciado" <?php echo e($paciente->estado_civil == 'Divorciado' ? 'selected' : ''); ?>>Divorciado</option>
                                <option value="Separado" <?php echo e($paciente->estado_civil == 'Separado' ? 'selected' : ''); ?>>Separado</option>
                                <option value="Soltero" <?php echo e($paciente->estado_civil == 'Soltero' ? 'selected' : ''); ?>>Soltero</option>
                                <option value="Union Libre" <?php echo e($paciente->estado_civil == 'Union Libre' ? 'selected' : ''); ?>>Union Libre</option>
                            </select>
                            
                        </div>

                        <!--Años-->
                        <div class="col-md-6 mb-2">
                            <label for="anios" class="form-label">Años</label>
                            <input type="number" class="form-control" id="anios" name="anios" min="0"
                                placeholder="Años del estado civil" value="<?php echo e($paciente->anios); ?>" required>
                            
                        </div>

                        <!--Nombres completo del Esposo-->
                        <div class="col-md-12 mb-2">
                            <label for="nombre_esposo" class="form-label">Nombres completo del Esposo(a)</label>
                            <input type="text" class="form-control" id="nombre_esposo" name="nombre_esposo"
                                placeholder="Nombre Completo" value="<?php echo e($paciente->nombre_esposo); ?>" required>
                            
                        </div>

                        <!--Edad del Esposo-->
                        <div class="col-md-5 mb-2">
                            <label for="edad_esposo" class="form-label">Edad Esposo(a)</label>
                            <input type="number" class="form-control" id="edad_esposo" name="edad_esposo"
                                min="0" placeholder="Edad esposo" value="<?php echo e($paciente->edad_esposo); ?>" required>
                            
                        </div>

                        <!--Grado de Instrucción-->
                        <div class="col-md-7 mb-2">
                            <label for="grado_instruccion" class="form-label">Grado de Instrucción</label>
                            <select class="form-select" id="grado_instruccion" name="grado_instruccion" required>
                                <option selected disabled value="">-- Seleccione --</option>
                                <option value="Primaria" <?php echo e($paciente->grado_instruccion == 'Primaria' ? 'selected' : ''); ?>>Primaria</option>
                                <option value="Secundaria" <?php echo e($paciente->grado_instruccion == 'Secundaria' ? 'selected' : ''); ?>>Secundaria</option>
                                <option value="Bachiller" <?php echo e($paciente->grado_instruccion == 'Bachiller' ? 'selected' : ''); ?>>Bachiller</option>
                                <option value="Profesional" <?php echo e($paciente->grado_instruccion == 'Profesional' ? 'selected' : ''); ?>>Profesional</option>
                            </select>
                            
                        </div>

                        <!--Cantidad de Hijos-->
                        <div class="col-md-12 mb-2">
                            <label for="cantidad_hijos" class="form-label">Cantidad de Hijos</label>
                            <input type="number" class="form-control" id="cantidad_hijos" name="cantidad_hijos"
                                min="0" placeholder="Introduzca la cantidad de Hijos que tiene" value="<?php echo e($paciente->cantidad_hijos); ?>" required>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row d-flex justify-content-between mb-3">
                        <!--Ocupación-->
                        <div class="col-md-12 mb-2">
                            <label for="ocupacion" class="form-label">Ocupación</label>
                            <input type="text" class="form-control" id="ocupacion" name="ocupacion"
                                placeholder="Escriba la ocupación" value="<?php echo e($paciente->ocupacion); ?>" required>
                            
                        </div>

                        <!--Ingreso Mensual-->
                        <div class="col-md-7 mb-2">
                            <label class="form-label" for="ingreso_mensual">Ingreso Mensual</label>
                            <div class="input-group">
                                <div class="input-group-text">Bs.</div>
                                <input type="number" class="form-control" id="ingreso_mensual"
                                    placeholder="Digite en Bs." name="ingreso_mensual" min="0" value="<?php echo e($paciente->ingreso_mensual); ?>" required>
                                
                            </div>
                        </div>

                        <!--Motivo de Consulta-->
                        <div class="col-md-12">
                            <label for="motivo_consulta" class="form-label">Motivo de Consulta</label>
                            <textarea class="form-control" id="motivo_consulta" name="motivo_consulta"
                                placeholder="Describa el motivo de la consulta" rows="7" required><?php echo e($paciente->motivo_consulta); ?></textarea>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--END Card group-->

        <!--START Car Group 3-->
        <div class="card-group mb-3">
            <div class="card">
                
                <div class="card-body">
                    <!--Entrevista Inicial-->
                    <fieldset>
                        <legend>Entrevista Inicial</legend>
                        <div class="row d-flex justify-content-between mb-3">
                            <!--Historia Familiar-->
                            <div class="col-md-12 mb-3">
                                <label for="historia_familiar" class="form-label">Historia Familiar</label>
                                <textarea
                                    class="form-control"
                                    id="historia_familiar"
                                    name="historia_familiar"
                                    placeholder="Describa la historia familiar del paciente"
                                    rows="5"
                                    required
                                ><?php echo e($paciente->historia_familiar); ?></textarea>
                                
                            </div>

                            <!--Tipo de Familia-->
                            <div class="col-md-6 mb-2">
                                <label for="tipo_familia" class="form-label">Tipo de Familia</label>
                                <select class="form-select" id="tipo_familia" name="tipo_familia" required>
                                    <option selected disabled value="">-- Seleccione --</option>
                                    <option value="Monoparental" <?php echo e($paciente->tipo_familia == 'monoparental' ? 'selected' : ''); ?>>Monoparental</option>
                                    <option value="Nuclear" <?php echo e($paciente->tipo_familia == 'nuclear' ? 'selected' : ''); ?>>Nuclear</option>
                                    <option value="Extensa" <?php echo e($paciente->tipo_familia == 'extensa' ? 'selected' : ''); ?>>Extensa</option>
                                    <option value="Ampliada" <?php echo e($paciente->tipo_familia == 'ampliada' ? 'selected' : ''); ?>>Ampliada</option>
                                    <option value="Reconstituida" <?php echo e($paciente->tipo_familia == 'reconstituida' ? 'selected' : ''); ?>>Reconstituida</option>
                                </select>
                                
                            </div>

                            <!--Tipo-->
                            <div class="col-md-6 mb-2">
                                <label for="tipo" class="form-label">Tipo</label><br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="tipo" id="funcional"
                                        value="funcional" <?php echo e($paciente->tipo == 'funcional' ? 'checked' : ''); ?> required>
                                    <label class="form-check-label" for="funcional">Funcional</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="tipo" id="disfuncional"
                                        value="disfuncional" <?php echo e($paciente->tipo == 'disfuncional' ? 'checked' : ''); ?> required>
                                    <label class="form-check-label" for="disfuncional">Disfuncional</label>
                                </div>
                            </div>

                        </div>
                    </fieldset>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <fieldset>
                        <legend>Relaciones Familiares</legend>
                        <div class="row justify-content-between">
                            <div class="col-md-6 mb-2">
                                <div class="card">
                                    <div class="card-header text-center">
                                        <span class="h6">Relación Conyugal</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                name="conyugal"
                                                id="estables"
                                                value="estables" <?php echo e($paciente->conyugal == 'estables' ? 'checked' : ''); ?>

                                                required
                                            >
                                            <label class="form-check-label" for="estables">Estables</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                name="conyugal"
                                                id="estrecho"
                                                value="estrecho" <?php echo e($paciente->conyugal == 'estrecho' ? 'checked' : ''); ?>

                                            >
                                            <label class="form-check-label" for="estrecho">Estrecho</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                name="conyugal"
                                                id="distante"
                                                value="distante" <?php echo e($paciente->conyugal == 'distante' ? 'checked' : ''); ?>

                                            >
                                            <label class="form-check-label" for="distante">Distante</label>
                                        </div>
                                        <div class="form-check form-check-inline m-0">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                name="conyugal"
                                                id="conflictivo"
                                                value="conflictivo" <?php echo e($paciente->conyugal == 'conflictivo' ? 'checked' : ''); ?>

                                            >
                                            <label class="form-check-label" for="conflictivo">Conflictivo</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input
                                                class="form-check-input"
                                                type="radio"
                                                id="otros-conyugal"
                                                value="otros-conyugal"
                                                name="conyugal"
                                            >
                                            <label class="form-check-label" for="otros-conyugal">Otros</label>
                                        </div>
                                        <!-- Se muestra según el radiobutton seleccionado-->
                                        <div id="input-otro-conyugal"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="card">
                                    <div class="card-header text-center">
                                        <span class="h6">Relación Materno-Filial</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="materno"
                                                id="estables-materno" value="estables" <?php echo e($paciente->materno == 'estables' ? 'checked' : ''); ?> required>
                                            <label class="form-check-label" for="estables-materno">Estables</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="materno"
                                                id="estrecho-materno" value="estrecho" <?php echo e($paciente->materno == 'estrecho' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="estrecho-materno">Estrecho</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="materno"
                                                id="distante-materno" value="distante" <?php echo e($paciente->materno == 'distante' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="distante-materno">Distante</label>
                                        </div>
                                        <div class="form-check form-check-inline m-0">
                                            <input class="form-check-input" type="radio" name="materno"
                                                id="conflictivo-materno" value="conflictivo" <?php echo e($paciente->materno == 'conflictivo' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="conflictivo-materno">Conflictivo</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" id="otros-materno"
                                                value="otros-materno" name="materno">
                                            <label class="form-check-label" for="otros-materno">Otros</label>
                                        </div>
                                        <!-- Se muestra según el radiobutton seleccionado-->
                                        <div id="input-otro-materno"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="card">
                                    <div class="card-header text-center">
                                        <span class="h6">Relación Paterno-Filial</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="paterno"
                                                id="estables-paterno" value="estables" <?php echo e($paciente->paterno == 'estables' ? 'checked' : ''); ?> required>
                                            <label class="form-check-label" for="estables-paterno">Estables</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="paterno"
                                                id="estrecho-paterno" value="estrecho" <?php echo e($paciente->paterno == 'estrecho' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="estrecho-paterno">Estrecho</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="paterno"
                                                id="distante-paterno" value="distante" <?php echo e($paciente->paterno == 'distante' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="distante-paterno">Distante</label>
                                        </div>
                                        <div class="form-check form-check-inline m-0">
                                            <input class="form-check-input" type="radio" name="paterno"
                                                id="conflictivo-paterno" value="conflictivo" <?php echo e($paciente->paterno == 'conflictivo' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="conflictivo-paterno">Conflictivo</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" id="otros-paterno"  name="paterno" value="otros-paterno"  <?php echo e($paciente->paterno == 'otra cosa' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="otros-paterno">Otros</label>
                                        </div>
                                        <!-- Se muestra según el radiobutton seleccionado-->
                                        <div id="input-otro-paterno"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="card">
                                    <div class="card-header text-center">
                                        <span class="h6">Relación Fraterno-Filial</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="fraterno"
                                                id="estables-fraterno" value="estables" <?php echo e($paciente->fraterno == 'estables' ? 'checked' : ''); ?> required>
                                            <label class="form-check-label" for="estables-fraterno">Estables</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="fraterno"
                                                id="estrecho-fraterno" value="estrecho" <?php echo e($paciente->fraterno == 'estrecho' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="estrecho-fraterno">Estrecho</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="fraterno"
                                                id="distante-fraterno" value="distante" <?php echo e($paciente->fraterno == 'distante' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="distante-fraterno">Distante</label>
                                        </div>
                                        <div class="form-check form-check-inline m-0">
                                            <input class="form-check-input" type="radio" name="fraterno"
                                                id="conflictivo-fraterno" value="conflictivo" <?php echo e($paciente->fraterno == 'conflictivo' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="conflictivo-fraterno">Conflictivo</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" id="otros-fraterno"
                                                value="otros-fraterno" name="fraterno">
                                            <label class="form-check-label" for="otros-fraterno">Otros</label>
                                        </div>
                                        <!-- Se muestra según el radiobutton seleccionado-->
                                        <div id="input-otro-fraterno"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>
        </div>
        <!--END Card group-->


        <!--START Car Group 3-->
        <div class="card-group mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="row d-flex justify-content-between mb-3">
                        <div class="col-md-12 my-2">
                            <label for="diagnostico_social" class="form-label">Diagnóstico Social:</label>
                            <div class="form-floating">
                                <textarea
                                    class="form-control"
                                    placeholder="Diagnóstico Social:"
                                    id="diagnostico_social"
                                    style="height: 120px"
                                    name="diagnostico_social"
                                    required
                                ><?php echo e($paciente->diagnostico_social); ?></textarea>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row d-flex justify-content-between mb-3">
                        <div class="col-md-12 my-2">
                            <label for="acciones" class="form-label">Acciones a Seguir:</label>
                            <div class="form-floating">
                                <textarea
                                    class="form-control"
                                    placeholder="Acciones a Seguir"
                                    id="acciones"
                                    style="height: 120px"
                                    name="acciones"
                                    required
                                ><?php echo e($paciente->acciones); ?></textarea>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <button class="btn btn-primary" type="submit" id="submit">Actualizar</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

    <!-- JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>

    

    

    <script>

        (function () {

            document.addEventListener("DOMContentLoaded", function (event) {
                eventListeners();
                mostrarInput(event);
                /*document.querySelector('#otros-conyugal').dispatchEvent(new Event('click'));
                document.querySelector('#otros-fraterno').dispatchEvent(new Event('click'));*/
            });

            function eventListeners() {
                // Muestra campos condicionales
                const metodoMostrarInputText_conyugal = document.querySelectorAll(
                    'input[name="conyugal"]'
                );
                const metodoMostrarInputText_materno = document.querySelectorAll(
                    'input[name="materno"]'
                );
                const metodoMostrarInputText_paterno = document.querySelectorAll(
                    'input[name="paterno"]'
                );
                const metodoMostrarInputText_fraterno = document.querySelectorAll(
                    'input[name="fraterno"]'
                );
                // console.log(metodoMostrarInputText_conyugal[0].name);
                // para iterar cuando sea más de 1, y añadir ese addEventListener
                metodoMostrarInputText_conyugal.forEach((input) =>
                    input.addEventListener("click", mostrarInputText_RelacionesFamiliares)
                );
        
                metodoMostrarInputText_materno.forEach((input) =>
                    input.addEventListener("click", mostrarInputText_RelacionesFamiliares)
                );
        
                metodoMostrarInputText_paterno.forEach((input) =>
                    input.addEventListener("click", mostrarInputText_RelacionesFamiliares)
                );
        
                metodoMostrarInputText_fraterno.forEach((input) =>
                    input.addEventListener("click", mostrarInputText_RelacionesFamiliares)
                );
            }

            

            function mostrarInputText_RelacionesFamiliares(e) {
                /** Para mostrar el cuadro de texto en caso de que necesite describir otro - Relacione Familiares */
                const inputOtro_conyugal = document.querySelector("#input-otro-conyugal");
                const inputOtro_materno = document.querySelector("#input-otro-materno");
                const inputOtro_paterno = document.querySelector("#input-otro-paterno");
                const inputOtro_fraterno = document.querySelector("#input-otro-fraterno");

                //console.log(e.target.name + ' => ' + e.target.value);
                /*let radioOtrosConyugal = document.getElementById('otros-conyugal');
                console.log("Valor: " + radioOtrosConyugal.value);*/

                if (e.target.value === "otros-conyugal") {
                    //console.log('SON IGUALES');
                    inputOtro_conyugal.innerHTML = `
                        <input type="text" class="form-control" id="otros-conyugal-I" name="conyugal" placeholder="Describa..." value="<?php echo e($paciente->conyugal); ?>" required>
                        `;
                    /*let nuevo = document.getElementById('otros-conyugal-I').value;
                    console.log(nuevo);*/
                    console.log(inputOtro_conyugal);

                } else {
                    if (e.target.name === "conyugal") {
                        inputOtro_conyugal.innerHTML = "";
                    }
                }

                if (e.target.value === "otros-materno") {
                    inputOtro_materno.innerHTML = `
                        <input type="text" class="form-control" id="otros-materno" name="materno" placeholder="Describa..." value="<?php echo e($paciente->materno); ?>" required>
                        `;
                    console.log(inputOtro_materno);

                } else {
                    if (e.target.name === "materno") {
                        inputOtro_materno.innerHTML = "";
                    }
                }
        
                if (e.target.value === "otros-paterno") {
                    inputOtro_paterno.innerHTML = `
                        <input type="text" class="form-control" id="otros-paterno" name="paterno" placeholder="Describa..." value="<?php echo e($paciente->paterno); ?>" required>
                        `;
                    console.log(inputOtro_paterno);
                } else {
                    if (e.target.name === "paterno") {
                        inputOtro_paterno.innerHTML = "";
                    }
                }
        
                if (e.target.value === "otros-fraterno") {
                    inputOtro_fraterno.innerHTML = `
                        <input type="text" class="form-control" id="otros-fraterno-F" name="fraterno" placeholder="Describa..." value="<?php echo e($paciente->fraterno); ?>" required>
                        `;
                    //let nuevoF = document.getElementById('otros-fraterno-F').value;
                    //console.log(nuevoF);
                    console.log(inputOtro_fraterno);
                } else {
                    if (e.target.name === "fraterno") {
                        inputOtro_fraterno.innerHTML = "";
                    }
                }
                //console.log(e.target.name + ' => ' + e.target.value);
            }

            function mostrarInput(e){
                //Inputs radio
                let radioOtrosConyugal = document.getElementById('otros-conyugal');
                let radioOtrosMaterno = document.getElementById('otros-materno');
                let radioOtrosPaterno = document.getElementById('otros-paterno');
                let radioOtrosFraterno = document.getElementById('otros-fraterno');

                //console.log(radioOtrosPaterno.name);
                //el e.targer.value no es buena idea, porque espera el click al parecer
                if(radioOtrosPaterno === 'otros-paterno' ){
                    
                }

                /** Conyugal */
                radioOtrosConyugal.addEventListener('click', e => {});
                radioOtrosConyugal.dispatchEvent(new Event('click'));
                radioOtrosConyugal.checked = true;

                /** Materno */
                radioOtrosMaterno.addEventListener('click', e => {});
                radioOtrosMaterno.dispatchEvent(new Event('click'));
                radioOtrosMaterno.checked = true;

                /** Paterno */
                radioOtrosPaterno.addEventListener('click', e => {});
                radioOtrosPaterno.dispatchEvent(new Event('click'));
                //radioOtrosPaterno.checked = true;

                /** Fraterno */
                radioOtrosFraterno.addEventListener('click', e => {});
                radioOtrosFraterno.dispatchEvent(new Event('click'));
                radioOtrosFraterno.checked = true;
            }
        })();
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/pacientes/editBackup.blade.php ENDPATH**/ ?>